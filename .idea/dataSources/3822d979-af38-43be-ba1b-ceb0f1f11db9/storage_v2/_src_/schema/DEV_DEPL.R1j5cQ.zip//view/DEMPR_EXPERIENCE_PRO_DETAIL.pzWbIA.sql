create view DEMPR_EXPERIENCE_PRO_DETAIL as
select a."ID_EXPERIENCE",a."CODE_CV",a."POSTE",a."DOMAINE",a."SOCIETE",a."MOIS_XP",a."DATE_DEBUT",a."DATE_FIN",a."MOIS_XP_LIBELLE",b.descri_poste,c.descri_domaine,d.descri_societe from dempr_experience_pro a join dempr_poste b on a.poste=b.id_poste join dempr_domaine c on a.domaine=c.id_domaine join dempr_societe d on a.societe=d.id_societe

/

