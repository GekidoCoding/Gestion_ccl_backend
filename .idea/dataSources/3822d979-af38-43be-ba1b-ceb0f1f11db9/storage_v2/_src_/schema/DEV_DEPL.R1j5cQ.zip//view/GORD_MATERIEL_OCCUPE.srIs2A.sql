create view GORD_MATERIEL_OCCUPE as
select "ID_MVT","NUM_SERIE_MAT","MATRICULE_AGENT","DATE_DEBUT_MVT","DATE_FIN_MVT","FLAG_MVT","USER_MAJ","OBSERVATION","NOM_MAT","NUM_INVENTAIRE_MAT","USER_INSERT_MAT","DATE_INSERT_MAT","NOM_AGENT","CODE_DIRECTION","LIBELLE_DIRECTION","CODE_SERVICE","LIB_SERVICE","CODE_FONCTION","LIBELLE_FONCTION" from(select mvt.*,
mat.nom_mat,mat.num_inventaire_mat,mat.user_insert user_insert_mat,mat.date_insert date_insert_mat,
ag.nom_agent,ag.code_direction,ag.libelle_direction,ag.code_service,ag.lib_service,ag.code_fonction,ag.libelle_fonction
from IMMO.gord_mouvement_tt mvt join IMMO.gord_materiel_tt mat on mvt.num_serie_mat=mat.num_serie_mat
join DRH.agent_active ag on mvt.matricule_agent=ag.matricule) tab where date_fin_mvt is null

/

