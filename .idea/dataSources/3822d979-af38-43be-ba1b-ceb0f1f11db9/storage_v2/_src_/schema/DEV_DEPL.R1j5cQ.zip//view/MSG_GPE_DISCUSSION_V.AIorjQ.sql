create view MSG_GPE_DISCUSSION_V as
select b."ID",b."NOM_GROUPE",b."DESCRIPTION_GROUPE",b."DATE_CREATE",b."USER_CREATE",b."USER_MAJ",b."DATE_MAJ",b."ETAT",b."COMMENTS",b."ID_LASTMSG", 
    c.id_part , c.contenu ,c.path_filename,c.name_file,c.user_insert as user_insertf,c.user_maj as user_majf,case when c.date_insert is null then b.date_create
    else c.date_insert end as date_insertf
    ,c.date_maj as date_majf,c.comments as commentsf,c.type_msg,c.type_file FROM (
    select a.*,DEV_DEPL.MSG_GET_IDLASTMSG(a.id) as id_lastmsg  from DEV_DEPL.MSG_GPE_DISCUSSION a) b LEFT join DEV_DEPL.MSG_GPE_MESSAGE c ON b.id_lastmsg = c.id

/

