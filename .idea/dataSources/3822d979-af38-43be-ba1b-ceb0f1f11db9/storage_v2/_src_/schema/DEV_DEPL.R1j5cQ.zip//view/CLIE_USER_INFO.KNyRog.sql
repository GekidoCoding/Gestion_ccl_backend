create view CLIE_USER_INFO as
select a.user_matricule,a.username user_oracle,a.code_dr,a.user_init,b.nom,b.prenoms,c.CODE_SERVICE,c.LIB_SERVICE 
from treso.cnaps_user a 
join drh.drh_renseignement_agent b on a.user_matricule=b.agent_matricule
join DRH.agent_active_dr c on b.agent_matricule=c.MATRICULE

/

