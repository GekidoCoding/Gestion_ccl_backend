create trigger INFRA_APPART_TRIGGER
    after insert or update
    on INFRA_LOG_APPART
    for each row
DECLARE
    action_type VARCHAR2(15); 
BEGIN
	IF INSERTING THEN
        action_type := 'CREATE';

    ELSIF UPDATING THEN
        IF :OLD.deleted != :NEW.deleted THEN
            RETURN;
        ELSE
            action_type := 'UPDATE';
        END IF;
    END IF;
    INSERT INTO Infra_Historique (entite, id, nom, action, matricule, timestamp)
    VALUES (
        'APPARTEMENT',
        :NEW.id_appartement,
        :NEW.nom_appartement,
        action_type,
        :NEW.matricule,
        CURRENT_TIMESTAMP
    );
END;
/

