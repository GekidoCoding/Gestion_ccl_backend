create view VW_DUREE_PAR_DEMANDE_JOURS as
SELECT 
    h5.id_demande_ve,
    h5.date_ajout AS date_non_traitee,
    h4.date_ajout AS date_traitee,
    ROUND(CAST(h4.date_ajout AS DATE) - CAST(h5.date_ajout AS DATE), 2) AS duree_jours
FROM 
    historique_demande_ve h5
JOIN 
    historique_demande_ve h4
    ON h5.id_demande_ve = h4.id_demande_ve
    AND h5.id_etat = 5      -- non traitée
    AND h4.id_etat = 4      -- traitée
    AND h4.date_ajout = (
        SELECT MIN(h4_sub.date_ajout)
        FROM historique_demande_ve h4_sub
        WHERE h4_sub.id_demande_ve = h5.id_demande_ve
          AND h4_sub.id_etat = 4
          AND h4_sub.date_ajout > h5.date_ajout
    )
/

