create view VW_AGING_RETARDS as
SELECT
    v.ID_DEMANDE,
    v.ID_VENTILATION,
    d.ID_DETAIL,
    CASE
        WHEN TRUNC(SYSDATE) - d.date_echeance <= 30 THEN '0-30 jours'
        WHEN TRUNC(SYSDATE) - d.date_echeance <= 60 THEN '31-60 jours'
        WHEN TRUNC(SYSDATE) - d.date_echeance <= 90 THEN '61-90 jours'
        ELSE '>90 jours'
    END AS tranche_retard,
    SUM(GREATEST(d.montant_du - NVL(p.montant_paye,0), 0)) AS montant_en_retard
FROM VE_VENTILATION v
JOIN VE_VENTILATION_DETAIL d ON v.ID_VENTILATION = d.ID_VENTILATION
LEFT JOIN VE_PAIEMENT p ON d.ID_DETAIL = p.ID_VENTILATION_detail
WHERE d.date_echeance < TRUNC(SYSDATE)
GROUP BY v.ID_DEMANDE, v.ID_VENTILATION, d.ID_DETAIL,
         CASE
            WHEN TRUNC(SYSDATE) - d.date_echeance <= 30 THEN '0-30 jours'
            WHEN TRUNC(SYSDATE) - d.date_echeance <= 60 THEN '31-60 jours'
            WHEN TRUNC(SYSDATE) - d.date_echeance <= 90 THEN '61-90 jours'
            ELSE '>90 jours'
         END
HAVING SUM(GREATEST(d.montant_du - NVL(p.montant_paye,0), 0)) > 0
ORDER BY v.ID_DEMANDE, d.ID_DETAIL
/

