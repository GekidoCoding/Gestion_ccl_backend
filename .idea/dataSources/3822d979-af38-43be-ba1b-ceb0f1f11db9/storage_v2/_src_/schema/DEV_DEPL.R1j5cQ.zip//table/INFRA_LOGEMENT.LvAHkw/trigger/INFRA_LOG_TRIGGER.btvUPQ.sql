create trigger INFRA_LOG_TRIGGER
    after insert or update
    on INFRA_LOGEMENT
    for each row
DECLARE
    action_type VARCHAR2(15); 
    details_json CLOB;
BEGIN
	IF INSERTING THEN
        action_type := 'CREATE';

    ELSIF UPDATING THEN
        IF :OLD.deleted != :NEW.deleted THEN
            RETURN;
        ELSE
            action_type := 'UPDATE';
        END IF;
    END IF;
    details_json := '{"id": "' || :NEW.id_logement || '", "matricule": "' || :NEW.matricule || '", "nom": "' || :NEW.nom_logement || '"}';
    INSERT INTO Infra_Historique (entite, id, nom, action, matricule, timestamp)
    VALUES (
        'LOGEMENT',
        :NEW.id_logement,
        :NEW.nom_logement,
        action_type,
        :NEW.matricule,
        CURRENT_TIMESTAMP
    );
END;
/

