create trigger TRG_PROJET
    before insert
    on KPI_PROJET
    for each row
BEGIN 
    SELECT 'PRJ'||LPAD(dev_depl.kpi_seq_projet.NEXTVAL, 10, '0') INTO :NEW.id_projet FROM DUAL;
END;
/

