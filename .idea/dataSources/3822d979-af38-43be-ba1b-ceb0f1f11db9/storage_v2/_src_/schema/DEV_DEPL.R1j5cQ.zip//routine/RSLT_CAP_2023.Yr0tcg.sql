create PROCEDURE      rslt_CAP_2023 IS    
--declare
rg number;
BEGIN
    begin
    delete DRH.COMMIS_RESULTAT_VOTE_2023;
    commit;
    end;
    for c in (SELECT  CODE_CATEG cat FROM DRH.COMMIS_PARITAIRE_CAT order by CODE_CATEG asc)
    loop
     rg:=1;
    for d in (SELECT MATRICULE a,ETAT_TRAITEMENT t, NOM b, PRENOM c,   SERVICE d , CODE_CATEG e,   VOIX g,CATEGORIE h
    FROM DRH.COMMIS_PARITAIRE_RESULTAT where CODE_CATEG=c.cat order by VOIX desc, MATRICULE asc)
    loop
    begin
    insert into DRH.COMMIS_RESULTAT_VOTE_2023 (MATRICULE_CANDIDAT,ETAT_TRAITEMENT, NOM_CANDIDAT, PRENOM_CANDIDAT, 
       SERVICE_CANDIDAT, CODE_CATEG_CANDIDAT, VOIX, CATEGORIE, RANG) values
       (d.a, d.t,d.b, d.c, d.d, d.e, d.g, d.h, rg);
    commit;
    end;
    rg:=rg+1;
    end loop;
    end loop;
END;
/

