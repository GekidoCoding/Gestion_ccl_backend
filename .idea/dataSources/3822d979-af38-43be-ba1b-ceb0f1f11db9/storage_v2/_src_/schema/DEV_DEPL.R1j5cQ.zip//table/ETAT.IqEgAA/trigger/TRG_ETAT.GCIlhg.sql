create trigger TRG_ETAT
    before insert
    on ETAT
    for each row
BEGIN
  :NEW.id_etat := seq_etat.NEXTVAL;
END;
/

