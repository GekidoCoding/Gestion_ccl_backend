create trigger TRG_MOTIF_DEMANDE
    before insert
    on VE_MOTIF_DEMANDE
    for each row
BEGIN
  :NEW.id_motif_demande := seq_motif_demande.NEXTVAL;
END;
/

