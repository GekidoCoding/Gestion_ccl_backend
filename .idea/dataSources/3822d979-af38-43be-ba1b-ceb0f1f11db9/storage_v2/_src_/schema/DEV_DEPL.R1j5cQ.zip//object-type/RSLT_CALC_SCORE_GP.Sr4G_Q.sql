create TYPE          rslt_calc_score_GP  AS OBJECT (
    Score_realisation           NUMBER,
    realisation_pondere   NUMBER,
    kpi            NUMBER
);
/

