create view VW_TAUX_PAIEMENT_EMPLOYEUR as
SELECT
    d.matricule_employeur AS employeur_id,                    
    SUM(vd.montant_du) AS montant_total_prevu,               
    SUM(NVL(p.montant_paye,0)) AS montant_total_paye,       
    ROUND(SUM(NVL(p.montant_paye,0)) / SUM(vd.montant_du) * 100, 2) AS taux_paiement_pct
FROM VE_VENTILATION v
JOIN VE_VENTILATION_DETAIL vd ON v.ID_VENTILATION = vd.ID_VENTILATION
JOIN ve_demande_ve d ON v.ID_DEMANDE = d.id_demande_ve
LEFT JOIN VE_PAIEMENT p ON vd.ID_DETAIL = p.ID_VENTILATION_detail
GROUP BY d.matricule_employeur
ORDER BY taux_paiement_pct DESC
/

