create view DEMPR_RECHERCHE_CV as
select a."DESCRI_OBSERVATION",a."NUMERO_DOSSIER",a."DATE_RECEPTION",a."ETAT",a."OBSERVATION",a."CODE_CV",a."NOM",a."PRENOM",a."DATE_NAISSANCE",a."LIEU_NAISSANCE",a."SEXE",a."ADRESSE",a."TELEPHONE",a."EMAIL",a."POSTE_DEMANDEE",a."TYPE_DEMANDE",a."PROVENANCE",a."DESCRI_TYPE_DEMANDE",a."DESCRI_DEMANDE",a."AGE",a."SITUATION_FAMILIALE",a."TOTAL_MOIS_XP",a."TOTAL_MOIS_XP_LIBELLE",
case when a.observation is not null then 
(a.numero_dossier || ' ' ||a.nom || ' ' || a.prenom || ' ' || a.email || ' ' || a.sexe || ' ' ||a.telephone|| ' ' || a.descri_demande|| ' ' ||a.descri_type_demande|| ' ' ||a.provenance|| ' ' ||a.code_cv
|| ' ' || a.descri_observation)
else (a.numero_dossier || ' ' ||a.nom || ' ' || a.prenom || ' ' || a.email || ' ' || a.sexe || ' ' ||a.telephone|| ' ' || a.descri_demande|| ' ' ||a.descri_type_demande|| ' ' ||a.provenance|| ' ' ||a.code_cv) end  recherche

 from dempr_cv_detail a
where etat='V'

/

