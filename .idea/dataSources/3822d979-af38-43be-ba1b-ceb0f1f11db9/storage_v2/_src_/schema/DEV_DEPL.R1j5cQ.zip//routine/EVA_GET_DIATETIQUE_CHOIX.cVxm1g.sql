create FUNCTION  EVA_GET_DIATETIQUE_CHOIX(form_codee varchar2,quest_codee varchar2) RETURN varchar2 IS
    retour varchar2(500);
    BEGIN
        BEGIN 
            select lib_prest into retour  from drh.VIEW_HEAD_FORM_DIATETIQUE where form_code = form_codee and quest_code = quest_codee ;
             exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        RETURN(retour);
    END;

/

