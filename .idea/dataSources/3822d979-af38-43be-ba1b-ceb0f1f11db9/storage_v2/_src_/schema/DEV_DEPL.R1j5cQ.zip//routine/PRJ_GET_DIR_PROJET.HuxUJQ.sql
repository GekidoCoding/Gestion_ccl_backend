create FUNCTION          PRJ_GET_DIR_PROJET(id_projet VARCHAR2) RETURN VARCHAR2 AS
    result_string VARCHAR2(4000);
    BEGIN
        SELECT LISTAGG(libelle_direction || ' (' || code_direction || ')', ', ') WITHIN GROUP (ORDER BY libelle_direction) INTO result_string
        FROM (
            SELECT CODE_DIRECTION, LIBELLE_DIRECTION FROM DRH.DRH_DIRECTION WHERE CODE_DIRECTION IN (
            SELECT sce.code_direction FROM DEV_DEPL.PRJ_CLIENTS cli 
            LEFT JOIN DRH.DRH_SERVICE sce ON cli.code_service = sce.code_service 
            WHERE cli.id_prj=id_projet AND cli.etat_clt = 1)
        );
        IF result_string IS NULL THEN
            result_string:='-';
        END IF;
        RETURN result_string;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '-'; 
    END;
/

