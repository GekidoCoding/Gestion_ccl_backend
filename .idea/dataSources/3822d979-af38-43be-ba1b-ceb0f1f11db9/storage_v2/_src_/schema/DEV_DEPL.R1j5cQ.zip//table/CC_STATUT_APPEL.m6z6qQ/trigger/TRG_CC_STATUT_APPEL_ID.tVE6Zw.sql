create trigger TRG_CC_STATUT_APPEL_ID
    before insert
    on CC_STATUT_APPEL
    for each row
BEGIN
    :NEW.id_statut_appel := seq_cc_statut_appel.NEXTVAL;
END;
/

