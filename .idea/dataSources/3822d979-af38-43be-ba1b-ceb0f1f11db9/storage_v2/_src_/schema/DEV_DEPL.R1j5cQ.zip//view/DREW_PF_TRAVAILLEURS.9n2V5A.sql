create view DREW_PF_TRAVAILLEURS as
SELECT
   
    sig.sig_dossiers.dossier_numero,
    sig.sig_dossiers.employeur_matricule,
    sig.sig_dossiers.travailleur_matricule,
    sig.sig_dossiers.dossier_date_reception,
    sig.sig_dossiers.sous_prestation_code,
    sig.sig_travailleurs.travailleur_nom,
    sig.sig_travailleurs.travailleur_prenom,
    sig.sig_travailleurs.travailleur_numero_cin
FROM
    sig.sig_dossiers
    LEFT JOIN sig.sig_travailleurs ON sig.sig_dossiers.travailleur_matricule = sig.sig_travailleurs.travailleur_matricule
    where sig.sig_dossiers.flag_valide_n2 = 'O'
    order by  sig.sig_dossiers.dossier_date_reception desc

/

