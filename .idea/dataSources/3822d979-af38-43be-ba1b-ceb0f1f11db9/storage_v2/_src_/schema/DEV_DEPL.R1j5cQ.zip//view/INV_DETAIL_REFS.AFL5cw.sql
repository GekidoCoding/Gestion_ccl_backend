create view INV_DETAIL_REFS as
SELECT 
a.cle_spe id,
a.specif_spe specif_code,
a.libelle_spe specif_lib,
a.nature_spe nature_code,
c.libelle_nat nature_lib,
a.classe_spe classe_code,
b.classe_lib classe_lib,
concat(concat(c.libelle_nat,' '),trim(a.libelle_spe)) designation 
FROM INV_IMMO_SPECIFICITES a 
JOIN INV_IMMO_CLASSES b ON a.classe_spe=b.classe_code 
join INV_immo_natures c on a.nature_spe=c.nature_nat and a.classe_spe=c.classe_nat
/

