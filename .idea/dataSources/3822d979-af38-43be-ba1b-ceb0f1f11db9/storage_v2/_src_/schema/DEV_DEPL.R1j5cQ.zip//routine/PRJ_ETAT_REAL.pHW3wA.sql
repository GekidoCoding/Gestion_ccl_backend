create FUNCTION          PRJ_ETAT_REAL(etatt number,nb_spec number) RETURN number IS
    retour number;
    -- etat_termine number:=21;
    -- etat_maint number:=22;
    BEGIN
        -- IF etatt = etat_termine AND nb_spec = 0 THEN
        --     retour:=etat_termine;
        -- ELSIF etatt = etat_termine AND nb_spec > 0 THEN
        --     retour:=etat_maint;
        -- ELSE
        --     retour:=etatt;
        -- END IF;
        retour:=etatt;
        return(retour);
    END;
/

