create view AMBU_INTERVENTION_DETAILS as
select interv."ID",interv."NUMERO_AT",interv."ETAT",interv."DATE_EVENEMENT",interv."USER_INSERT",interv.TARIF,
interl.matricule,interl.nom,interl.prenom,interl.numero,interl.email,
locali.description description,locali.fiv_code,fiv.FIV_NOM,locali.far_code,far.faritany_nom far_nom,locali.firaisana_code,fir.firaisana_nom,locali.fkt_code,fkt.fkt_nom,
att.TRAVAILLEUR_MATRICULE,att.TRAVALLEUR_NOM_AT,att.TRAVAILLEUR_PRENOM_AT,att.TRAVAILLEUR_CIN,
att.EMPLOYEUR_AT,att.DECLARATION_ACCIDENT_CIRCONSTA,empl.employeur_nom
from ambu_intervention interv left join ambu_interlocuteur interl on interv.id=interl.id_intervention
left join ambu_localisation locali on locali.id_intervention=interv.id 
left join sig.sig_fiv fiv on locali.fiv_code=fiv.fiv_code
left join sig.sig_far far on locali.far_code=far.faritany_code
left join sig.sig_fir fir on locali.firaisana_code=fir.firaisana_code
left join sig.sig_fkt fkt on locali.fkt_code=fkt.fkt_code
left join sig.sig_at_dsp att on att.numero_at=interv.numero_at
left join sig.sig_employeurs empl on att.EMPLOYEUR_AT=empl.employeur_matricule

/

