create view CC_V_NB_APPEL_AGENT as
select agent_matricule, trunc(date_heure_appel) as date_appel, count(id_appel) as nb_appel 
        from cc_appel  
    group by agent_matricule, trunc(date_heure_appel) 
    order by nb_appel desc
/

