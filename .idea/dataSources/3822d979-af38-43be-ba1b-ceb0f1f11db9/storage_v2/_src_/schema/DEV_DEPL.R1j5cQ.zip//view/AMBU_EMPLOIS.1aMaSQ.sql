create view AMBU_EMPLOIS as
select "EMPLOYEUR_MATRICULE","EMPLOYEUR_NOM","TRAVAILLEUR_MATRICULE","TRAVAILLEUR_NOM","TRAVAILLEUR_PRENOM",
"TRAVAILLEUR_NUMERO_CIN","EMPLOI_DATE_EMBAUCHE","EMPLOI_DATE_DEBAUCHE",nom_complet,TRAVAILLEUR_SEXE from
(select empl.employeur_matricule,empl.employeur_nom,trav.travailleur_matricule,trav.travailleur_nom,trav.travailleur_prenom,trav.TRAVAILLEUR_SEXE,trav.travailleur_numero_cin,
refer.emploi_date_embauche,refer.emploi_date_debauche,(trav.travailleur_nom || ' ' ||trav.travailleur_prenom) nom_complet
from SIG.sig_employeurs empl join sig.sig_emplois refer on empl.employeur_matricule=refer.employeur_matricule
join SIG.sig_travailleurs trav on trav.travailleur_matricule=refer.travailleur_matricule)tab where tab.emploi_date_debauche is NULL

/

