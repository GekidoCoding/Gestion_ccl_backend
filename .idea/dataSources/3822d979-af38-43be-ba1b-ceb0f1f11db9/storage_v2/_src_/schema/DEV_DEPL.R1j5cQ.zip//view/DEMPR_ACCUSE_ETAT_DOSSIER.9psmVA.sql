create view DEMPR_ACCUSE_ETAT_DOSSIER as
select a."NUMERO_ACCUSE",a."DATE_ACCUSE",a."REMETTANT",a."USER_INSERT",a."NUMERO_DOSSIER",
a."ETAT",a."NOTE",b.etat etat_dossier,b.type_demande,c.descri_type_demande
from dempr_accuse_reception a 
join dempr_dossier b on a.numero_dossier=b.numero_dossier
join dempr_type_demande c on b.type_demande=c.id_type_demande

/

