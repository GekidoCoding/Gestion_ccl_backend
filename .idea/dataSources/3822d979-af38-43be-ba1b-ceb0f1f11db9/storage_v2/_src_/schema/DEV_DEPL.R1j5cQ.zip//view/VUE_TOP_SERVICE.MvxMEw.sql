create view VUE_TOP_SERVICE as
SELECT
    s.idservice,
    s.libelleservice,
    COUNT(t.idactivite) AS nb_taches
FROM ga_activites t
JOIN ga_agents a ON t.idagent = a.idagent
JOIN ga_services s ON a.idservice = s.idservice
GROUP BY s.idservice, s.libelleservice
/

