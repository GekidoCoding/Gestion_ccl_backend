create view INV_IMMO_CLASSES as
SELECT 
    "CLASSE_CODE"
    ,"CLASSE_LIB"
FROM IMMO.IMMO_CLASSES clas where clas.classe_lib is not null

/

