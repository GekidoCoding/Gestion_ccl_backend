create view CLIE_CODE_TRESO_DN as
SELECT TYPcpt_LIBELLE, TYPcPt_CODE FROM treso.trs_TYPES_comptes WHERE TYPCPT_type='DN0'
and (rtrim(TYPcPt_code))IN('800','810','811','812')
ORDER BY TYPcPt_code ASC

/

