create view DEMPR_PJ_DETAIL as
select
a."ID_FICHIER_ATTACHE",a."TYPE_FICHIER_ATTACHE",a."URL",a."NUMERO_DOSSIER",a."DATE_ENTREE",a."ETAT",a."DESCRIPTION_FICHIER",b.descri_type_fichier from dempr_fichier_attache a join dempr_type_fichier b on a.type_fichier_attache=b.id_type_fichier

/

