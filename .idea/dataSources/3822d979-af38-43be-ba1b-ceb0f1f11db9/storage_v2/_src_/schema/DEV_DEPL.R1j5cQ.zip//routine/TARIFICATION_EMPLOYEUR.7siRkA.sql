create FUNCTION     tarification_employeur(empl VARCHAR2, per NUMBER) RETURN CHAR IS
  nb_ti NUMBER(5) := 0;
  v_cie CHAR(1) := 'N';
  v_code VARCHAR2(3);
  v_montant NUMBER(14, 2);
  v_solde NUMBER(14, 3) := 0;
  v_sens CHAR(1);
  v_tar NUMBER(14, 3) := 0;

  CURSOR cie IS
    SELECT TRS_COMPTES_EMPLOYEURS.TYPCPT_CODE,
           TRS_COMPTES_EMPLOYEURS.COMPTE_SENS,
           TRS_COMPTES_EMPLOYEURS.CPTEMP_MONTANT
    FROM sig.TRS_COMPTES_EMPLOYEURS
    WHERE TRS_COMPTES_EMPLOYEURS.EMPLOYEUR_MATRICULE = empl
      AND TRS_COMPTES_EMPLOYEURS.TYPCPT_CODE NOT IN ('40', '43', '46')
      AND TRS_COMPTES_EMPLOYEURS.PERIODE = per;

BEGIN
  IF per >= '200201' THEN
    nb_ti := 0;
    v_solde := 0;
    v_tar := 0;

    OPEN cie;
    LOOP
      FETCH cie INTO v_code, v_sens, v_montant;
      EXIT WHEN cie%NOTFOUND;
      IF v_code IN ('910', '900') THEN  --tarification
        v_tar := v_tar + v_montant;
      ELSE
        IF v_sens = 'C' THEN
          v_solde := v_solde + NVL(v_montant, 0);
        ELSE
          v_solde := v_solde - NVL(v_montant, 0);
        END IF;
      END IF;
    END LOOP;
    CLOSE cie;

    IF v_solde > 0 THEN
      IF v_tar > 0 THEN
        IF v_solde >= v_tar * 0.8 THEN
          RETURN 'O';
        ELSE
          RETURN 'N';
        END IF;
      ELSE
        RETURN 'O';
      END IF;
    ELSE
      RETURN 'N';
    END IF;
  ELSE
    RETURN 'O';
  END IF;
END;

/

