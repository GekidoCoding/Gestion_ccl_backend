create view DN_DERNIER_ACTIVITE_DATE as
SELECT act_empl.EMPLOYEUR_MATRICULE, max(act_empl.activite_empl_date) dateActivite FROM sig.sig_activites_empl act_empl
            group by act_empl.EMPLOYEUR_MATRICULE

/

