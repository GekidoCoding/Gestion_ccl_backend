create view DEMPR_PJ_DETAIL_MARKET_PLACE as
SELECT a."ID_FICHIER_ATTACHE",
          a."TYPE_FICHIER_ATTACHE",
          a."URL",
          a."NUMERO_DOSSIER",
          a."DATE_ENTREE",
          a."ETAT",
          a."DESCRIPTION_FICHIER",
          a."MARKET_PLACE_CHECK",
          b.descri_type_fichier
     FROM    dempr_fichier_attache a
          JOIN
             dempr_type_fichier b
          ON a.type_fichier_attache = b.id_type_fichier

/

