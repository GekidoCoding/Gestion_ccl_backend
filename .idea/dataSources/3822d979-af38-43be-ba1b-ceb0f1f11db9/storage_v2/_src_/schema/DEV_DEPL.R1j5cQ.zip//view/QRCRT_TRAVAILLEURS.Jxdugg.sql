create view QRCRT_TRAVAILLEURS as
(
   SELECT distinct(trav.travailleur_matricule),
          trav.travailleur_nom,
          trav.travailleur_prenom,
          trav.travailleur_numero_cin,
          trav.travailleur_date_nais,
          trav.travailleur_date_adhesion
     FROM sig.sig_travailleurs trav
)

/

