create view CLIE_ETS_FINANCIERS as
SELECT trs_ets_financiers.ets_financiers_code,
       trs_ets_financiers.ets_financiers_libelle
  FROM treso.trs_ets_financiers
 WHERE  ETS_FINANCIERS_ABREV not like '%.%'
and ETS_FINANCIERS_ABREV not like ('PTE%')

/

