create view PRJ_SPECIFICATION_DET_V as
select s."ID_SPE",s."ETAT_SPE",s."ID_PRJ",s."CONTENU",s."OBSERVATION",s."COMMENTS",s."USER_INSERT",s."DATE_INSERT",s."USER_MAJ",s."DATE_MAJ",s."TYPE_SPE", t.libelle as libelle_type_spe, t.type_spe as typ_code_spe from dev_depl.prj_specification_det s 
join dev_depl.prj_type_specification t on s.type_spe = t.code_spe
/

