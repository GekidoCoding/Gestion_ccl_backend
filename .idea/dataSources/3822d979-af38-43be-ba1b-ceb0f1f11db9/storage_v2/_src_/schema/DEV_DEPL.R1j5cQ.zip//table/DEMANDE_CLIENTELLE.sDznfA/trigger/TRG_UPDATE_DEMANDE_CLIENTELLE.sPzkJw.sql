create trigger TRG_UPDATE_DEMANDE_CLIENTELLE
    before update
    on DEMANDE_CLIENTELLE
    for each row
BEGIN
    IF :new.DATE_MAJ IS NULL THEN
        :new.DATE_MAJ := SYSDATE ;
    END IF;
    IF :new.USER_CREATE IS NULL THEN
        :new.USER_MAJ := USER ;
    END IF;
END ;
/

