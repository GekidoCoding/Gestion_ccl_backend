create FUNCTION          PRJ_COUNT_SPEC(id_prjj varchar2,etatspec number) RETURN number IS
    retour number;
    BEGIN
        BEGIN
            SELECT count(*) INTO retour
            FROM DEV_DEPL.PRJ_SPECIFICATION_DET
            WHERE ID_PRJ = id_prjj AND etat_spe = etatspec; 
            exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
            IF retour=null THEN
                retour:=0;
            END IF;
        END;
        RETURN(retour);
    END;
/

