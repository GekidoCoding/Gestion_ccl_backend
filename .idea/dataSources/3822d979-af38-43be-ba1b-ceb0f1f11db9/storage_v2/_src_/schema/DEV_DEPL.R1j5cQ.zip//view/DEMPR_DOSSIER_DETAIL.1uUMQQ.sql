create view DEMPR_DOSSIER_DETAIL as
SELECT 
    a."NUMERO_DOSSIER",a."DATE_RECEPTION",a."ETAT",a."OBSERVATION",a."TYPE_DEMANDE",
    b.descri_type_demande
FROM dempr_dossier a join dempr_type_demande b on a.type_demande=b.id_type_demande

/

