create FUNCTION     numeroter_op(s_prestation char) RETURN char IS
 v_jour  char(2);
 v_annee char(3);
 v_mois  char(2);
 v_seq_op number;
 v_seq_op1 varchar2(12);
 v_num_op char(15);
BEGIN
   SELECT to_char(sysdate,'DD') into v_jour  FROM sys.dual;
   SELECT to_char(sysdate,'MM') into v_mois  FROM sys.dual;
   SELECT substr(to_char(sysdate,'YYYY'),1,1)||to_char(sysdate,'YY')
   INTO v_annee FROM sys.dual;
   SELECT PF.PF_SEQ_OP.nextval into v_seq_op FROM sys.dual;
   v_seq_op1 := '00000'||to_char(v_seq_op);
   v_num_op := s_prestation||
               v_annee||
               v_mois||
               v_jour||
               '42'||substr(v_seq_op1,-3,3);
   Return(v_num_op);
END;

/

