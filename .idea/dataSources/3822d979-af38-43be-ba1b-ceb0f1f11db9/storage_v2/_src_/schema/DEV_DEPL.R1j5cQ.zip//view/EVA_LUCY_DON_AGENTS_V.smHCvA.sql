create view EVA_LUCY_DON_AGENTS_V as
SELECT
    ag."EVA_CODE",ag."AGENT_MATRICULE",ag."EVA_PERIODE",ag."CODE_CATEGORIE",ag."CODE_DIRECTION",ag."CODE_SERVICE",ag."CODE_FONCTION",ag."ETAT",ag."COMMENTS",ag."INSERT_AT",ag."MODIF_AT",ag."OBS_AGENT",
    per.LIBELLE,
    per.etat as etat_periode,
    v.nom,
    v.prenoms,
    serv.libelle_service,
    dir.libelle_direction,
    fn.libelle_fonction,
    fn.type_fonction
FROM DEV_DEPL.EVA_LUCY_DON_AGENTS ag JOIN DEV_DEPL.EVA_LUCY_SESSION per ON ag.EVA_PERIODE = per.PERIODE
    JOIN INTRANET.view_annuaire_electronique v ON ag.AGENT_MATRICULE=v.matricule
    LEFT JOIN DRH.DRH_SERVICE serv ON ag.code_service = serv.code_service
    LEFT JOIN DRH.DRH_DIRECTION dir ON ag.code_direction = dir.code_direction
    LEFT JOIN DRH.DRH_FONCTION fn ON ag.code_fonction = fn.code_fonction

/

