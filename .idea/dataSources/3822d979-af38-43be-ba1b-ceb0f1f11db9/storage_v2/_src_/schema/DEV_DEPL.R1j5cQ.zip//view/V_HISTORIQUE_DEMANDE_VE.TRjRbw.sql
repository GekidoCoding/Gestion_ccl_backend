create view V_HISTORIQUE_DEMANDE_VE as
SELECT
    d.id_demande_ve,
    CAST(d.date_demande AS TIMESTAMP) AS date_demande,
    d.periode_debut,
    d.periode_fin,
    d.nombre_mois_paiement,
    d.montant_total,
    d.date_debut_paiement,
    e_actuel.libelle AS etat_actuel,
    
    CAST(h.date_ajout AS TIMESTAMP) AS date_evenement,
    e_historique.libelle AS etat_evenement,
    h.description,
    h.decision,
    h.motifs_refus,
    
    m.libelle AS motif_initial

FROM ve_demande_ve d

LEFT JOIN historique_demande_ve h
    ON d.id_demande_ve = h.id_demande_ve

LEFT JOIN ve_etat e_actuel
    ON d.id_etat_demande = e_actuel.id_etat

LEFT JOIN ve_etat e_historique
    ON h.id_etat = e_historique.id_etat

LEFT JOIN ve_motif_demande m
    ON d.id_motif = m.id_motif_demande
/

