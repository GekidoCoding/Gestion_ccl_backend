create view VUE_BEST_AGENT as
SELECT
    a.idAgent,
    a.matriculeagent,
    a.nomAgent,
    a.prenomsagent,
    COUNT(t.idActivite) AS nb_activites
FROM GA_ACTIVITES t
JOIN GA_AGENTS a ON t.idagent = a.idagent
GROUP BY a.idAgent, a.matriculeagent, a.nomagent, a.prenomsagent
/

