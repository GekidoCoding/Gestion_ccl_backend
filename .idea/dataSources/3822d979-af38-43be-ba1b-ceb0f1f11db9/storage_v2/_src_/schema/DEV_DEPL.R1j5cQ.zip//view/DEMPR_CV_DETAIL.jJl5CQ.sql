create view DEMPR_CV_DETAIL as
select obs.descri_observation,tab2."NUMERO_DOSSIER",tab2."DATE_RECEPTION",tab2."ETAT",
tab2."OBSERVATION",tab2."CODE_CV",tab2."NOM",tab2."PRENOM",tab2."DATE_NAISSANCE",
tab2."LIEU_NAISSANCE",tab2."SEXE",
tab2."ADRESSE",tab2."TELEPHONE",tab2."EMAIL",tab2."POSTE_DEMANDEE",tab2."TYPE_DEMANDE",tab2."PROVENANCE",
tab2."DESCRI_TYPE_DEMANDE",tab2."DESCRI_DEMANDE",tab2."AGE",tab2."SITUATION_FAMILIALE",
tab2."TOTAL_MOIS_XP",tab2."TOTAL_MOIS_XP_LIBELLE"
from dempr_observation obs 
right join 
(select a.numero_dossier,a.date_reception,a.etat,a.observation,a.type_demande,tab.code_cv,tab.nom,tab.prenom,tab.date_naissance,
tab.lieu_naissance,tab.sexe,tab.adresse,tab.telephone,tab.email,tab.poste_demandee,tab.provenance
,a.descri_type_demande,tab.descri_demande,tab.age,tab.situation_familiale,tab.total_mois_xp,tab.total_mois_xp_libelle 
from dempr_dossier_detail a left join
(select a.*,c.descri_demande from dempr_cv a
right join dempr_poste_demande c on c.id_poste=a.poste_demandee) tab
on a.numero_dossier=tab.numero_dossier) tab2 on obs.id_observation=tab2.observation

/

