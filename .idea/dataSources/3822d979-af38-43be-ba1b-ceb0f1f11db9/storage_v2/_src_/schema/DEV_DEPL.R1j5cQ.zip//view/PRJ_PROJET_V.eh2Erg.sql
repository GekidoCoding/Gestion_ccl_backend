create view PRJ_PROJET_V as
SELECT
    prj.ID_PRJ,
    prj.DESIGNATION as INTITULE_PROJET,
    prj.OBSERVATION as OBS_PROJET,
    prj.DEBUT_DELAI,
    prj.FIN_DELAI,
    prj.ETAT_PRJ,
    prj.ID_PHASE,
    prj.USER_INSERT as USER_INSERT_PRJ,
    prj.DATE_INSERT as DATE_INSERT_PRJ,
    prj.DIR_INIT,
    prj.SCE_CIBLE,
    phase.LIBELLE as LIBELLE_PHASE,
    DEV_DEPL.PRJ_GET_SCE_PROJET(prj.ID_PRJ) as service_concern,
    DEV_DEPL.PRJ_GET_DIR_PROJET(prj.ID_PRJ) as direction_concern,
    dir.libelle_direction as libelle_dir_init,
    DEV_DEPL.PRJ_GET_PART_PROJET(prj.ID_PRJ,'CLT','O') as interlocuteur_client,
    DEV_DEPL.PRJ_GET_PART_PROJET(prj.ID_PRJ,'DSI','O') as responsable_dsi,
    DEV_DEPL.PRJ_COUNT_SPEC(prj.ID_PRJ,1) as spec_attente,
    DEV_DEPL.PRJ_ETAT_REAL(prj.ETAT_PRJ,DEV_DEPL.PRJ_COUNT_SPEC(prj.ID_PRJ,1)) as etat_reel -- avadika procédure ty fa tsy zao aloha
    FROM DEV_DEPL.PRJ_REF_PROJET prj LEFT JOIN DEV_DEPL.PRJ_PHASE_PROJET phase ON prj.ID_PHASE = phase.ID_PHASE LEFT JOIN DRH.DRH_DIRECTION dir
    ON prj.DIR_INIT = dir.code_direction
/

