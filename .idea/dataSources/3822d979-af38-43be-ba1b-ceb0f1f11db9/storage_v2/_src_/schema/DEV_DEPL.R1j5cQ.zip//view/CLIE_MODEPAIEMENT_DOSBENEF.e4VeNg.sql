create view CLIE_MODEPAIEMENT_DOSBENEF as
select ben."DOSSIER_NUMERO",ben."BENEFICIAIRE",ben."CODE_BANQUE",ben."CODE_AGENCE",ben."MODE_PAIEMENT",ben."NUMERO_COMPTE",ben."CLE_RIB",ben."NOM",ben."PRENOMS",ben."ADRESSE",ben."CIN",ben."DATE_CIN",ben."SEXE",ben."DATE_NAISSANCE",ben."USER_INSERT",ben."DATE_INSERT",ben."ETAT",ben."MEMO_MODIF",ben."MODE_PAIEMENT_CODE",bq.banque_libelle,ag.agence_libelle,mdp.mode_libelle mode_paiement_libelle from clie_dossiers_beneficiaire ben 
left join TRESO.trs_banques bq on ben.code_banque=bq.banque_code
left join TRESO.trs_banques_agences ag on ben.code_agence=ag.agence_code and ben.code_banque=ag.banque_code
left join treso.trs_modepaiements mdp on ben.mode_paiement_code=mdp.mode_code

/

