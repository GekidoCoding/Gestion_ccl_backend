create trigger TRG_VE_FONCTION_RESPONSABLE
    before insert
    on VE_FONCTION_RESPONSABLE
    for each row
BEGIN
  IF :NEW.id_fonction_responsable IS NULL THEN
    SELECT seq_ve_fonction_responsable.NEXTVAL INTO :NEW.id_fonction_responsable FROM dual;
  END IF;
END;
/

