create view VW_DUREE_MOYENNE_PAR_MOTIF as
SELECT
    d.id_motif,
    m.libelle,
    ROUND(AVG(CAST(h4.date_ajout AS DATE) - CAST(h5.date_ajout AS DATE)), 2) AS duree_moy_traitement_jours
FROM
    ve_demande_ve d
JOIN historique_demande_ve h5
    ON d.id_demande_ve = h5.id_demande_ve
    AND h5.id_etat = 5  -- non traitée
JOIN historique_demande_ve h4
    ON d.id_demande_ve = h4.id_demande_ve
    AND h4.id_etat = 4  -- traitée
    AND h4.date_ajout = (
        SELECT MIN(h4_sub.date_ajout)
        FROM historique_demande_ve h4_sub
        WHERE h4_sub.id_demande_ve = d.id_demande_ve
          AND h4_sub.id_etat = 4
          AND h4_sub.date_ajout > h5.date_ajout
    )
JOIN ve_motif_demande m
    ON d.id_motif = m.id_motif_demande
GROUP BY
    d.id_motif,
    m.libelle
/

