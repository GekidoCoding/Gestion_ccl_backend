create trigger TRG_CC_SERVICE_ID
    before insert
    on CC_SERVICE
    for each row
BEGIN
    :NEW.id_service := seq_cc_service.NEXTVAL;
END;
/

