create trigger INFRA_GITE_TRIGGER
    after insert or update
    on INFRA_GITE
    for each row
DECLARE
    action_type VARCHAR2(15); 
BEGIN
	IF INSERTING THEN
        action_type := 'CREATE';

    ELSIF UPDATING THEN
        IF :OLD.deleted != :NEW.deleted THEN
            RETURN;
        ELSE
            action_type := 'UPDATE';
        END IF;
    END IF;
    INSERT INTO Infra_Historique (entite, id, nom, action, matricule, timestamp)
    VALUES (
        'GITE',
        :NEW.id_gite,
        :NEW.nom_gite,
        action_type,
        :NEW.matricule,
        CURRENT_TIMESTAMP
    );
END;
/

