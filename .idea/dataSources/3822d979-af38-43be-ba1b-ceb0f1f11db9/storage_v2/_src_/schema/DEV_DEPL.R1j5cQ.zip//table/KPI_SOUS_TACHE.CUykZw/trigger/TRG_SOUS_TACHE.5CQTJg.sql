create trigger TRG_SOUS_TACHE
    before insert
    on KPI_SOUS_TACHE
    for each row
BEGIN 
    SELECT 'STC'||LPAD(dev_depl.kpi_seq_sous_tache.NEXTVAL, 10, '0') INTO :NEW.id_sous_tache FROM DUAL;
END;
/

