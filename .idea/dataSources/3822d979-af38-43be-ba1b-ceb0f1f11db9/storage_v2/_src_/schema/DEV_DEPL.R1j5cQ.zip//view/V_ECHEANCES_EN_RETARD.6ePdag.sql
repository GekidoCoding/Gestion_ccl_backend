create view V_ECHEANCES_EN_RETARD as
SELECT
    vent.id_demande,
    demande.matricule_employeur as matricule,
    vent.periode,
    d.id_detail AS id_detail,
    d.date_echeance,
    d.montant_du,
    d.montant_utilise,
    d.reste,
    d.etat,
    CURRENT_DATE - d.date_echeance AS jours_de_retard
FROM
    ve_ventilation_detail d
JOIN
    ve_ventilation vent ON d.id_ventilation = vent.id_ventilation
join ve_demande_ve demande on demande.id_demande_ve =  vent.id_demande
WHERE
    d.date_echeance < CURRENT_DATE
    AND (
        d.reste > 0
        OR (d.montant_utilise > d.montant_du AND d.reste > 0)
    )
ORDER BY
    jours_de_retard DESC
/

