create FUNCTION  EVA_GET_ENQ_NOTE(form_codee varchar2,quest_codee varchar2) RETURN number IS
    retour number;
    BEGIN
        BEGIN 
            select notes into retour from drh.EVA_ENQ_EAD_FORMDET where form_code = form_codee and quest_code = quest_codee ;
             exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        RETURN(retour);
    END;

    create or replace FUNCTION     EVA_GET_ENQ_OBS(form_codee varchar2,quest_codee varchar2) RETURN varchar2 IS
    retour varchar2(500);
    BEGIN
        BEGIN 
            select observation into retour from drh.EVA_ENQ_EAD_FORMDET where form_code = form_codee and quest_code = quest_codee ;
             exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        RETURN(retour);
    END;


CREATE OR REPLACE FORCE VIEW "DRH"."VIEW_HEAD_FORM_DIATETIQUE" ("QUEST_CODE", "QUEST_DETAILS", "ETAT","NOTE","FORM_CODE", "CRITERE_FR","CRITERE_MLG", "LIB_PREST","ETAT_FORM","TYPE") AS 
SELECT
    det."QUEST_CODE",det."QUEST_DETAILS",det."ETAT",det."NOTE",det."FORM_CODE", formm.CRITERE_FR,
    formm.CRITERE_MLG,list.lib_prest,
    formm.etat as etat_form,
    formm.type
FROM DRH.enquete_diatetique_detail_dmd det JOIN DRH.ENQUETE_PREST_FORM formm
ON det.FORM_CODE = formm.FORM_CODE
 left join DRH.enquete_prest_list list on det.PREST_CODE = list.prest_code;


/

