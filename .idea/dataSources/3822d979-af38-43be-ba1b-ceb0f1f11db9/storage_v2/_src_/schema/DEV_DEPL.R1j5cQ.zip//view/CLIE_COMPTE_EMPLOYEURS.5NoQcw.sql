create view CLIE_COMPTE_EMPLOYEURS as
select "EMPLOYEUR_MATRICULE","ETS_FIN_CODE","EMPL_COMPTE_NUMERO","EMPL_COMPTE_DATE","EMPL_COMPTE_CLE","EMPL_COMPTE_NOM","USER_INSERT","DATE_INSERT","USER_MODIF","DATE_MODIF","EMPL_COMPTE_DATE_FIN","SUCCURSALE_CODE","FLAG_COMPTE","CODEBANQUE","CODEAGENCE","ORIGINE_COMPTE","BANQUE_LIBELLE","AGENCE_LIBELLE" from (select tot.*,bq.banque_libelle,ag.agence_libelle from sig.sig_empl_comptestot tot 
left join TRESO.TRS_BANQUES bq on tot.codebanque=bq.banque_code
left join TRESO.TRS_BANQUES_AGENCES ag on (tot.codeagence=ag.agence_code and tot.codebanque=ag.banque_code))

/

