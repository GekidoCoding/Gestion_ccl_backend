create trigger TRG_PJ_PATR
    before insert
    on INFRA_PJ_PATRIMOINE
    for each row
BEGIN
    SELECT pj_patr_seq.NEXTVAL
    INTO :NEW.id_pj
    FROM dual;
END;
/

