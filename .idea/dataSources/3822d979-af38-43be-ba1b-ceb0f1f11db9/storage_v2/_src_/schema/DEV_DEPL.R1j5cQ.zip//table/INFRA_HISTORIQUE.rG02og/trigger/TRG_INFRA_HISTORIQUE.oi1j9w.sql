create trigger TRG_INFRA_HISTORIQUE
    before insert
    on INFRA_HISTORIQUE
    for each row
BEGIN
    SELECT historique_seq.NEXTVAL
    INTO :NEW.id_historique
    FROM dual;
END;
/

