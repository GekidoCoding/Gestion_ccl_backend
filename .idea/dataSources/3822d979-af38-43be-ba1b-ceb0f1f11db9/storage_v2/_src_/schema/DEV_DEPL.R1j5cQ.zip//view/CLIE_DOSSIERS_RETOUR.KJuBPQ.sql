create view CLIE_DOSSIERS_RETOUR as
select dr.NUMERO_RETOUR,
    dr.DOSSIER_NUMERO,
    dr.PRESTATION_CODE,
   dr.TRAVAILLEUR_MATRICULE,
    dr.SOUS_PRESTATION_CODE,
   dr.USER_INSERT,
   dr.DATE_RETOUR,
   dr.MOTIF_RETOUR,
   dr.AUT_MOTIF,mr.MOTIF from sig.sig_dossiers_retour dr left join sig.sig_motif_retour mr on dr.MOTIF_RETOUR=mr.MOTIF_RETOUR

/

