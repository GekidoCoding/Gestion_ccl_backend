create trigger TRG_VE_DEMANDE_VE
    before insert
    on VE_DEMANDE_VE
    for each row
BEGIN
  :NEW.id_demande_ve := seq_demande_ve.NEXTVAL;
END;
/

