create trigger TRG_HISTORIQUE_DEMANDE_VE
    before insert
    on HISTORIQUE_DEMANDE_VE
    for each row
BEGIN
  :NEW.id_historique_demande_ve := seq_historique_demande_ve.NEXTVAL;
END;
/

