create FUNCTION tarificationEmployeur(empl VARCHAR(100), per VARCHAR(100)) RETURNS CHAR(1)
BEGIN
  DECLARE v_tar DOUBLE;
  DECLARE v_solde DOUBLE;

  SELECT SUM(CASE WHEN TYPCPT_CODE IN ('910', '900') THEN CPTEMP_MONTANT ELSE 0 END) INTO v_tar
  FROM TRS_COMPTES_EMPLOYEURS
  WHERE EMPLOYEUR_MATRICULE = empl
    AND TYPCPT_CODE NOT IN ('40', '43', '46')
    AND PERIODE = per;

  SELECT SUM(CASE
               WHEN TYPCPT_CODE NOT IN ('910', '900') AND COMPTE_SENS = 'C' THEN CPTEMP_MONTANT
               WHEN TYPCPT_CODE NOT IN ('910', '900') AND COMPTE_SENS <> 'C' THEN -CPTEMP_MONTANT
               ELSE 0
             END) INTO v_solde
  FROM TRS_COMPTES_EMPLOYEURS
  WHERE EMPLOYEUR_MATRICULE = empl
    AND TYPCPT_CODE NOT IN ('40', '43', '46')
    AND PERIODE = per;

  IF per >= '200201' THEN
    IF v_solde > 0 THEN
      IF v_tar > 0 THEN
        IF v_solde >= v_tar * 0.8 THEN
          RETURN 'O';
        ELSE
          RETURN 'N';
        END IF;
      ELSE
        RETURN 'O';
      END IF;
    ELSE
      RETURN 'N';
    END IF;
  ELSE
    RETURN 'O';
  END IF;
END

/

