create view MOAPP_INFOS_PARCOURS_CLT as
SELECT PCLT."DOSSIER_NUMERO",
            PCLT."DR_CODE",
            PCLT."DR_NOM",
            PCLT."SOUS_PRESTATION_CODE",
            PCLT."SOUS_PRESTATION_LIB",
            PCLT."NUM_TRAV",
            PCLT."NOM_TRAV",
            PCLT."NUM_PEN",
            PCLT."NOM_PEN",
            PCLT."NUM_AT",
            PCLT."NOM_AT",
            PCLT."EMPLOYEUR_MATRICULE",
            PCLT."ACCEUIL",
            PCLT."PF",
            PCLT."PEN",
            PCLT."AT",
            PCLT."DATE_DISP",
            PCLT."USER_TTT",
            PCLT."NOM_TTT",
            PCLT."DATE_TTT",
            PCLT."TRACAGE_ACCEUIL",
            PCLT."TRACAGE_PF",
            PCLT."TRACAGE_PEN",
            PCLT."CLASSER",
            PCLT."ENQUETTE",
            PCLT."TRANSMISSION_TRESO",
            PCLT."TRANSMISSION_DT",
            PCLT."TRACAGE_SECDT",
            PCLT."TITRE_PAIEMENT",
            PCLT."DATE_BANQUE",
            PCLT."FLAG_DOSS",
            PCLT."OP",
            PCLT."DATE_OV",
            PCLT."MODE_PAIE",
            PCLT."FLAG_RETOURS",
            PCLT."MOTIF",
            PCLT."TRAV_CORRESP",
            PCLT."ENTREE_IMMA",
            PCLT."SORTIE_IMMA",
            TO_TIMESTAMP (PF) ENTRE_PF,
            TO_TIMESTAMP (PEN) ENTRE_PEN,
            TO_TIMESTAMP (AT) ENTRE_AT,
            DUREE_TTT,
            PCLT.ACCEUIL + DUREE_TTT TRAITEMENTNORME
       FROM    SIG.SIG_PARCOURS_CLT PCLT
            JOIN
               SIG.SIG_SOUS_PRESTATIONS
            ON TRIM (PCLT.SOUS_PRESTATION_CODE) =
                  TRIM (SIG.SIG_SOUS_PRESTATIONS.SOUS_PRESTATION_CODE)
      WHERE PCLT.ACCEUIL >= '01/01/2020'
   ORDER BY ACCEUIL

/

