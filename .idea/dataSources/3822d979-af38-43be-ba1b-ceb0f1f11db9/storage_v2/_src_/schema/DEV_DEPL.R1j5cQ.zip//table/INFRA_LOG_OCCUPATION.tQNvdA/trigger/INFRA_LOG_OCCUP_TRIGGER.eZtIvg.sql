create trigger INFRA_LOG_OCCUP_TRIGGER
    after insert or update
    on INFRA_LOG_OCCUPATION
    for each row
DECLARE
    action_type VARCHAR2(15); 
BEGIN
	IF INSERTING THEN
        action_type := 'CREATE';
    ELSIF UPDATING THEN
        action_type := 'UPDATE';
    END IF;
    INSERT INTO Infra_Historique (entite, id, nom, action, matricule, timestamp)
    VALUES (
        'OCCUPATION APPARTEMENT',
        :NEW.id_occupation,
        '',
        action_type,
        :NEW.matricule,
        CURRENT_TIMESTAMP
    );
END;
/

