create FUNCTION ve_employeur(empl char,per char) RETURN char IS  
   v_per number;

Begin 

begin
	SELECT count( PERIODE) into v_per
  FROM    TRESO.TRS_VE, TRESO.TRS_VE_REC
       where (TRS_VE.VE_ID = TRS_VE_REC.VE_ID)
       and EMPLOYEUR_MATRICULE=empl and PERIODE=per
       and nvl(FLAG_ANNULLER,'N')= 'N';
       exception when no_data_found then v_per:=0;
end;

  if v_per>0 then
 		return('N');
  else
  	return('O');  	
  End if;	

End;

/

