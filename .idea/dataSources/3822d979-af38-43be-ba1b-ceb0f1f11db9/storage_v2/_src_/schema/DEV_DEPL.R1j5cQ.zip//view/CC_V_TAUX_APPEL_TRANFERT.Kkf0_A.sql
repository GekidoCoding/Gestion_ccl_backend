create view CC_V_TAUX_APPEL_TRANFERT as
SELECT
        transfer,
        CASE 
            WHEN transfer = 1 THEN 'Transféré'
            ELSE 'Non transféré'
        END AS statut_transfert,
        COUNT(id_appel) AS nb_appel_total,
        ROUND(
            COALESCE(COUNT(transfer) * 100.0 / NULLIF(SUM(COUNT(id_appel)) OVER (), 0), 0),
            2
        ) AS taux_transfert
    FROM cc_v_details_appels
    GROUP BY 
        transfer
    ORDER BY
        transfer
/

