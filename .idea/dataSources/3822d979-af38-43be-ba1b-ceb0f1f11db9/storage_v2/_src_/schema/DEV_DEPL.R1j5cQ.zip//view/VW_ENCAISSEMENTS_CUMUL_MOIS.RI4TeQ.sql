create view VW_ENCAISSEMENTS_CUMUL_MOIS as
SELECT
    TRUNC(p.date_paiement, 'MM') AS mois_paiement,                 -- Mois de paiement
    SUM(p.montant_paye) AS montant_paye_mois,                      -- Montant payé dans le mois
    SUM(p.montant_du) AS montant_prevu_mois,                       -- Montant prévu dans le mois
    SUM(SUM(p.montant_paye)) OVER (ORDER BY TRUNC(p.date_paiement, 'MM')) AS montant_paye_cumule,      -- Paiements cumulés
    SUM(SUM(p.montant_du)) OVER (ORDER BY TRUNC(p.date_paiement, 'MM')) AS montant_prevu_cumule        -- Prévisions cumulées
FROM VE_PAIEMENT p
GROUP BY TRUNC(p.date_paiement, 'MM')
ORDER BY TRUNC(p.date_paiement, 'MM')
/

