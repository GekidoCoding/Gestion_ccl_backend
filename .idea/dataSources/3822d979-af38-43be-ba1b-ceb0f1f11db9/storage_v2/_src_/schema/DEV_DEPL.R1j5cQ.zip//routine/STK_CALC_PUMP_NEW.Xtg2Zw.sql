create FUNCTION        stk_calc_pump_new(art char,exo char,  qte number, pu number) RETURN char IS
situation varchar2(250);
art_sf char(8);
exo_sf char(4);
qte_sf number;
pu_sf number;
pump_new number;
qte_new number;
BEGIN


  Begin
        SELECT   EXERCICE, ARTICLE_CODE,  PUMP, QTE_FINAL
        into exo_sf, art_sf, pu_sf, qte_sf
        FROM COMPTA.STK_NEW_FINAL
        where EXERCICE=exo and  ARTICLE_CODE = art;
        Exception when no_data_found then exo_sf:=exo; art_sf:=art; pu_sf:=0; qte_sf:=0;
  End;
  if pu_sf>0 and  qte_sf>0 then
    qte_new:= nvl(qte_sf,0)+nvl(qte,0);
    pump_new:= (nvl(pu_sf,0)*nvl(qte_sf,0)+nvl(pu,0)*nvl(qte,0))/(nvl(qte_sf,0)+nvl(qte,0));
  else
    pump_new:=pu_sf;
    qte_new:=qte;
  end if;
  situation:='{ "stockInitial": '|| replace (qte_sf,',','.')||', "puInitial" : '||replace (pu_sf,',','.') ||',  "stockFinal" : '|| replace (qte_new,',','.')||', "pump" : '||replace (pump_new,',','.')||'}';
 -- situation:=replace (situation,',','.');
  return(situation);  
END;


--VUE SITUATION STOXK
SELECT DISTINCT
    COMPTA.STK_NEW_FINAL.id_final,
    COMPTA.STK_NEW_FINAL.date_maj,
    COMPTA.STK_NEW_FINAL.user_maj,
    COMPTA.STK_NEW_FINAL.exercice,
    COMPTA.STK_NEW_FINAL.article_code,
    COMPTA.ARTICLES.ARTICLE_LIBELLE,
    COMPTA.STK_NEW_FINAL.code_classe,
    stk_tb_classe3.LIBELLE_CLASSE,
    COMPTA.STK_NEW_FINAL.magasin_code,
    COMPTA.STK_NEW_FINAL.pump,
    COMPTA.STK_NEW_FINAL.qte_final,
    COMPTA.STK_NEW_FINAL.pu
FROM
    COMPTA.STK_NEW_FINAL, COMPTA.ARTICLES, compta.stk_tb_classe3
    WHERE COMPTA.STK_NEW_FINAL.ARTICLE_CODE = COMPTA.ARTICLES.ARTICLE_CODE
    AND COMPTA.STK_NEW_FINAL.CODE_CLASSE=compta.stk_tb_classe3.CODE_CLASSE;


/

