create FUNCTION  EVA_GET_DIATETIQUE_NOTE(form_codee varchar2,quest_codee varchar2) RETURN number IS
    retour number;
    BEGIN
        BEGIN 
            select NOTE  into retour from drh.VIEW_HEAD_FORM_DIATETIQUE where form_code = form_codee and quest_code = quest_codee ;
             exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        RETURN(retour);
    END;


/

