create FUNCTION          PRJ_COUNT_PLAN(id_plann varchar2) RETURN number IS
    retour number;
    BEGIN
        BEGIN
            SELECT count(*) INTO retour
            FROM DEV_DEPL.PRJ_TASK_PLANNING 
            WHERE id_plan = id_plann; 
            exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
            IF retour=null THEN
                retour:=0;
            END IF;
        END;
        RETURN(retour);
    END;
/

