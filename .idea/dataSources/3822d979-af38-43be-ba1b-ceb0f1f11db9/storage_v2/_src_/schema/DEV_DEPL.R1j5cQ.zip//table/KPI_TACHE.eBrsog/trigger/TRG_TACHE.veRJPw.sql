create trigger TRG_TACHE
    before insert
    on KPI_TACHE
    for each row
BEGIN 
    SELECT 'TCH'||LPAD(dev_depl.kpi_seq_tache.NEXTVAL, 10, '0') INTO :NEW.id_tache FROM DUAL;
END;
/

