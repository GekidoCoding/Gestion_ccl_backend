create view DN_EMPLOYEUR_INFO_ACTIVITE as
SELECT EMPLOYEUR_MATRICULE,
                        regime_code,
                        REGIME_CODE REGIME,
                        REGIME_TAUX_EMPL_RC TAUX_EMPL_RC,
                        REGIME_TAUX_TRAV_RC TAUX_TRAV_RC,
                        REGIME_TAUX_EMPL TAUX_EMPL,
                        REGIME_TAUX_TRAV TAUX_TRAV,
                        activite_empl_date 
        FROM    sig.sig_activites_empl act_empl 
        Join sig.sig_activites act 
        ON act_empl.activite_code = act.activite_code

/

