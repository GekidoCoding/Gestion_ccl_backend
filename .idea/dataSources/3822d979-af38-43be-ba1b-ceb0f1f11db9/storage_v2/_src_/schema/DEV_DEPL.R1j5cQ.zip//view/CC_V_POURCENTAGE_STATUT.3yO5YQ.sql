create view CC_V_POURCENTAGE_STATUT as
select 
        to_char(date_heure_appel, 'YYYY') as annee,
        to_char(date_heure_appel, 'MM') as mois_num,
        to_char(date_heure_appel, 'Month') as mois,
        id_statut_appel, statut_libelle, 
        count(id_appel) as nb_appel, 
        round((count(id_appel) * 100)/ (select count(id_appel) from cc_appel), 2) as pourcentage 
    from cc_v_details_appels 
        group by 
            id_statut_appel, 
            statut_libelle, 
            to_char(date_heure_appel, 'YYYY'),
            to_char(date_heure_appel, 'MM'), 
            to_char(date_heure_appel, 'Month')
        order by
            annee,
            mois_num
/

