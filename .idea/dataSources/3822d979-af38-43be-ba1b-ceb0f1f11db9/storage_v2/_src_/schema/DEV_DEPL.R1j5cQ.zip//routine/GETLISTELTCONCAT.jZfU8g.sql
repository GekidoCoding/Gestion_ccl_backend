create FUNCTION getListEltConcat(num_ticket VARCHAR2) RETURN VARCHAR2 AS
        result_string VARCHAR2(4000);
        BEGIN
            SELECT LISTAGG(designation_mat || '(' || qtte || ')', ', ') WITHIN GROUP (ORDER BY designation_mat) INTO result_string
            FROM (
                SELECT DISTINCT designation_mat, SUM(nombre) AS qtte
                FROM SIG.MAINT_DEMANDE_MAT_DET_V
                WHERE id_dmd = num_ticket AND designation_mat IS NOT NULL
                GROUP BY designation_mat
            );

            RETURN result_string;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RETURN '-'; 
        END;

/

