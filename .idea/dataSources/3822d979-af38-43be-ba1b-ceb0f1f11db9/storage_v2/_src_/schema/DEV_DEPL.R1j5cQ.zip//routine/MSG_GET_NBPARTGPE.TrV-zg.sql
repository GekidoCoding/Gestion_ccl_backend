create FUNCTION          MSG_GET_NBPARTGPE(id_gpee varchar2) RETURN number IS
    retour number;
    BEGIN
        BEGIN
            select count(*) into retour from DEV_DEPL.MSG_GPE_PARTICIPANT
            where  id_gpe = id_gpee and etat = 1;
            exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        RETURN(retour);
    END;

/

