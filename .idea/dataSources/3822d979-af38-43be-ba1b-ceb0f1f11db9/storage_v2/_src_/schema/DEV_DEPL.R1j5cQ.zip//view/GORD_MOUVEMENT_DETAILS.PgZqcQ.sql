create view GORD_MOUVEMENT_DETAILS as
select mvt."ID_MVT",mvt."NUM_SERIE_MAT",mvt."MATRICULE_AGENT",mvt."DATE_DEBUT_MVT",mvt."DATE_FIN_MVT",mvt."FLAG_MVT",mvt."USER_MAJ",mvt."OBSERVATION",
    mat.nom_mat,mat.num_inventaire_mat,mat.user_insert user_insert_mat,mat.date_insert date_insert_mat,
    ag.nom_agent,ag.code_direction,ag.libelle_direction,ag.code_service,ag.lib_service,ag.code_fonction,ag.libelle_fonction
from IMMO.gord_mouvement_tt mvt
join IMMO.gord_materiel_tt mat on mvt.num_serie_mat=mat.num_serie_mat
join DRH.agent_active ag on mvt.matricule_agent=ag.matricule

/

