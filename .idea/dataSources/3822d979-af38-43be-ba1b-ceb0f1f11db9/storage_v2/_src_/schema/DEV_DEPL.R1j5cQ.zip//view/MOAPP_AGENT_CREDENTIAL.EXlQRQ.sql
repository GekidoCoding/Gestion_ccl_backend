create view MOAPP_AGENT_CREDENTIAL as
select ag.matricule,ag.nom_agent,pwd.intranet_passe from DRH.agent_active_dr ag join INTRANET.intranet_users pwd on ag.matricule=pwd.matricule

/

