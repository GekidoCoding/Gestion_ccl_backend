create procedure     tarif_cot910(valperiode char, valEmpl char, val_dnrc char) as
v_regime char(2);
v_taux number(8,3);
v_nb_trav number(5):=0;
v_sal_plaf number(15,2);

v_m1 number(15,2);
v_m2 number(15,2);
v_m3 number(15,2);

v_m11 number(15,2);
v_m22 number(15,2);
v_m33 number(15,2);

v_trav char(17);
v_total_sal number(20,2):=0;
v_total_sal_trav number(20,2):=0;
v_total_sal_empl number(20,2):=0;

v_taux_trav number(8,3);
v_taux_empl number(8,3);

sp1 number(15,2);
sp2 number(15,2);
sp3 number(15,2);

vtp1 number(5,2);
vtp2 number(5,2);
vtp3 number(5,2);

ct1 number(12,2);
ct2 number(12,2);
ct3 number(12,2);

ce1 number(12,2);
ce2 number(12,2);
ce3 number(12,2);

salaire_m1 number(15,2);
salaire_m2 number(15,2);
salaire_m3 number(15,2);

v_sme1 char(1);
v_sme2 char(1);
v_sme3 char(1);

vsme1 number(15,2);
vsme2 number(15,2);
vsme3 number(15,2);
s2016m2 number(15,2);
s2016m1 number(15,2);

v_occ char(1);




CURSOR salaire is SELECT DISTINCT  TRAVAILLEUR_MATRICULE,          
                          nvl(CIT_SALAIRE_M1,0)+nvl(CIT_AVANTAGE_M1,0),
                           nvl(CIT_SALAIRE_M2,0)+nvl(CIT_AVANTAGE_M2,0),
                           nvl(CIT_SALAIRE_M3,0)+nvl(CIT_AVANTAGE_M3,0),
                           FLAG_OCC,CIT_PRESENCE_M1,CIT_PRESENCE_M2,CIT_PRESENCE_M3
                  FROM     sig.cit2
                   WHERE    employeur_matricule=valEmpl
                  and cit_periode=valperiode
                  and nvl(dn_rc,'N')=val_dnrc
                -- and TRAVAILLEUR_MATRICULE ='818227'   
                    ;

CURSOR salaire_GM is SELECT DISTINCT
                           TRAVAILLEUR_MATRICULE,          
                           nvl(CIT_SALAIRE_M1,0),
                           nvl(CIT_AVANTAGE_M1,0),
                           nvl(CIT_SALAIRE_M2,0),
                           nvl(CIT_AVANTAGE_M2,0),
                           nvl(CIT_SALAIRE_M3,0),
                           nvl(CIT_AVANTAGE_M3,0)
                  FROM     sig.cit2
                  WHERE    employeur_matricule=valEmpl
                  and cit_periode=valperiode
                  and nvl(dn_rc,'N')=val_dnrc;

nb1 number;
nb2 number;
nb3 number;


BEGIN
delete SIG.IMP_COTISATION910 where employeur_matricule=valEmpl
and dn_rc=val_dnrc and periode=valperiode;
commit;
--:en_cours:=0;
nb1:=0;
nb2:=0;
nb3:=0;
v_total_sal_empl:=0;
v_total_sal_trav:=0;

v_regime:=sig.tarif_regime(valEmpl, valperiode,val_dnrc);
v_taux:=sig.tarif_taux(valEmpl, valperiode,val_dnrc);
v_taux_trav:=sig.tarif_taux_trav (valEmpl, valperiode,val_dnrc);
v_taux_empl:=sig.tarif_taux_empl (valEmpl, valperiode,val_dnrc);
v_sal_plaf:=sig.tarif_salaire_plafone(valEmpl, valperiode,val_dnrc);
--synchronize;


if v_regime='GM' or val_dnrc='G' then
 v_total_sal:=0;
 v_total_sal_trav:=0;
 v_total_sal_empl:=0;
 ---calcul total montant plafonné par travailleur
  open salaire_gm;
  loop
     fetch salaire_gM into v_trav,v_m1,v_m11,v_m2,v_m22,v_m3,v_m33;
     exit when salaire_gm%notfound; 

    if v_m1<0 then v_m1:=0; end if;
    if v_m11<0 then v_m11:=0; end if;
    if v_m2<0 then v_m2:=0; end if;
    if v_m22<0 then v_m22:=0; end if;
    if v_m3<0 then v_m3:=0; end if;
    if v_m33<0 then v_m33:=0; end if;

     salaire_m1:=v_m1+v_m11;
     salaire_m2:=v_m2+v_m22;
     salaire_m3:=v_m3+v_m33;

      if nvl(salaire_m1,0)>0 then
          nb1:=nb1+1;
     end if;    
     if nvl(salaire_m2,0)>0 then
          nb2:=nb2+1;
     end if;
     if nvl(salaire_m3,0)>0 then
          nb3:=nb3+1;
     end if;    
     ---comparaison plafond

     if v_m1>=v_taux_empl then
       v_m1:=v_taux_empl;
     end if;
     if v_m2>=v_taux_empl then
       v_m2:=v_taux_empl;
     end if;
     if v_m3>=v_taux_empl then
       v_m3:=v_taux_empl;
     end if;
    ------cotisation employeur
     ce1:=v_m1;
     ce2:=v_m2;
     ce3:=v_m3;      

     v_total_sal_empl:=v_total_sal_empl+v_m1+v_m2+v_m3;      

     if v_m11>=v_taux_trav then
       v_m11:=v_taux_trav;
     end if;
     if v_m22>=v_taux_trav then
       v_m22:=v_taux_trav;
     end if;
     if v_m33>=v_taux_trav then
       v_m33:=v_taux_trav;
     end if;     
    -----cotisation trav 
     ct1:=v_m11;
     ct2:=v_m22;
     ct3:=v_m33; 
     ------------salaire plafonné
     sp1:=v_m1+v_m11;
     sp2:=v_m2+v_m22;
     sp3:=v_m3+v_m33;      

---- insertion table         
    insert into SIG.IMP_COTISATION910(EMPLOYEUR_MATRICULE  ,  
DN_RC                  ,
PERIODE                ,
TRAVAILLEUR_MATRICULE,
SALAIRE_M1           ,  
SP1                   , 
CT1                    ,
CE1                    ,
SALAIRE_M2             ,
SP2                    ,
CT2                    ,
CE2                    ,
SALAIRE_M3             ,
SP3                    ,
CT3                    ,
CE3,v_regime,
v_taux,
v_taux_trav,
v_taux_empl,
v_sal_plaf   ) values 
   (valEmpl            ,
val_dnrc                          ,
valperiode                     ,   
v_TRAV,          
SALAIRE_M1                     ,
SP1                            ,
CT1                            ,
CE1                            ,
SALAIRE_M2                     ,
SP2                            ,
CT2                            ,
CE2                            ,
SALAIRE_M3                     ,
SP3                            ,
CT3                            ,
CE3  ,                         
v_regime,
v_taux,
v_taux_trav,
v_taux_empl,
v_sal_plaf );
 commit;
     v_total_sal_trav:=v_total_sal_trav+v_m11+v_m22+v_m33;             

  end loop;
  close salaire_gm; 

   v_total_sal:=v_total_sal_trav+v_total_sal_empl;
   v_total_sal:=floor(v_total_sal);  

-----------------------------------------------  

else    
---calcul total montant plafonné par travailleur
  open salaire;
  loop
     fetch salaire into v_trav,v_m1,v_m2,v_m3,v_occ,vtp1,vtp2,vtp3;
     exit when salaire%notfound; 

    if v_m1<0 then v_m1:=0; end if;

    if v_m2<0 then v_m2:=0; end if;

    if v_m3<0 then v_m3:=0; end if;

      ----total salaire déclaré
     salaire_m1:=v_m1;
     salaire_m2:=v_m2;
     salaire_m3:=v_m3;

v_sme1 :=null;
v_sme2 :=null;
v_sme3 :=null;

vsme1 :=0;
vsme2 :=0;
vsme3 :=0;

     if nvl(salaire_m1,0)>0 then
          nb1:=nb1+1;
     end if;    
     if nvl(salaire_m2,0)>0 then
          nb2:=nb2+1;
     end if;
     if nvl(salaire_m3,0)>0 then
          nb3:=nb3+1;
     end if; 

          if valperiode='202202' then
            vsme1:= v_sal_plaf/8; 
                            if v_m1>=v_sal_plaf then
                   v_m1:=v_sal_plaf;
                            end if;
                                vsme2:= v_sal_plaf/8; 
                                        if v_m2>=v_sal_plaf then
                               v_m2:=v_sal_plaf;
                                        end if;
         elsif valperiode='201902' then
                           vsme1:= v_sal_plaf/8; 
                            if v_m1>=v_sal_plaf then
                   v_m1:=v_sal_plaf;
                            end if;
                                vsme2:= v_sal_plaf/8; 
                                        if v_m2>=v_sal_plaf then
                               v_m2:=v_sal_plaf;
                                        end if;
     elsif valperiode='201801' then
                           vsme1:= v_sal_plaf/8; 
                            if v_m1>=v_sal_plaf then
                   v_m1:=v_sal_plaf;
                            end if;
                            vsme2:= v_sal_plaf/8;
                  if v_m2>=v_sal_plaf then
                   v_m2:=v_sal_plaf;
                 end if;
    elsif valperiode='201701' then
                           vsme1:= v_sal_plaf/8; 
                            if v_m1>=v_sal_plaf then
                                v_m1:=v_sal_plaf;
                            end if;
                                if v_m2>=v_sal_plaf then
                                    v_m2:=v_sal_plaf;
                            end if;

   elsif valperiode='201601' then
           if v_regime='AG' then
                s2016m1:=1079360;
                s2016m2:=1120949.33;
            elsif v_regime='RG' then
                s2016m1:=1064107.2;
                s2016m2:=1105135.04;
            end if;
                  vsme1:= s2016m1/8; 
                            if v_m1>=s2016m1 then
                   v_m1:=s2016m1;
                            end if;
                            vsme2:= s2016m2/8;
                  if v_m2>=s2016m2 then
                   v_m2:=s2016m2;
                 end if;  
   elsif valperiode='201401' then
                           vsme1:= v_sal_plaf/8; 
                            if v_m1>=v_sal_plaf then
                   v_m1:=v_sal_plaf;
                            end if;
                            vsme2:= v_sal_plaf/8;
                  if v_m2>=v_sal_plaf then
                   v_m2:=v_sal_plaf;
                 end if;    
   ElsIf valperiode='201301' then
                                vsme1:= v_sal_plaf/8;
                            if v_m1>=v_sal_plaf then
                   v_m1:=v_sal_plaf;
                end if;
                      vsme2:= v_sal_plaf/8;
                  if v_m2>=v_sal_plaf then
                   v_m2:=v_sal_plaf;
                 end if;  
  ElsIf valperiode='200401' then 
        vsme1:= v_sal_plaf/8;    
      if v_m1>=v_sal_plaf then
       v_m1:=v_sal_plaf; 
      end if;
      vsme2:= v_sal_plaf/8; 
      if v_m2>=v_sal_plaf then
       v_m2:=v_sal_plaf;
     end if;

 ElsIf valperiode='200001' then 
           vsme1:= v_sal_plaf/8;   
        if v_m1>=v_sal_plaf then
           v_m1:=v_sal_plaf;           
        end if;
         vsme2:= v_sal_plaf/8; 
        if v_m2>=v_sal_plaf then
           v_m2:=v_sal_plaf;
        end if;

 Else
     vsme1:= v_sal_plaf/8;          
     if v_m1>=v_sal_plaf then
       v_m1:=v_sal_plaf;
     end if;
      vsme2:= v_sal_plaf/8; 
     if v_m2>=v_sal_plaf then
       v_m2:=v_sal_plaf;
     end if;

 End if;

     vsme3:= v_sal_plaf/8; 
     if v_m3>=v_sal_plaf then
       v_m3:=v_sal_plaf;
     end if;

     /*** SME***/

     if salaire_m1>0 and salaire_m1<vsme1 then
          v_sme1:='O';
     end if;    
     if salaire_m2>0 and salaire_m2<vsme2 then
          v_sme2:='O';
     end if;    
     if salaire_m3>0 and salaire_m3<vsme3 then
          v_sme3:='O';
     end if;     

  ------------salaire plafonné

     sp1:=v_m1;
     sp2:=v_m2;
     sp3:=v_m3; 
    -----cotisation trav
    if v_occ ='O' then --is not null then
           select SIG.arrondi_bqcentral ((sp1)/100)into ct1 from dual;   --floor((sp1*v_taux_trav)/100);
             select SIG.arrondi_bqcentral ((sp2)/100)into ct2 from dual; ---floor((sp2*v_taux_trav)/100);
            select SIG.arrondi_bqcentral ((sp3)/100)into ct3 from dual;

            v_total_sal_trav:=v_total_sal_trav+ ct1+ct2+ct3;
    else
         select SIG.arrondi_bqcentral ((sp1*v_taux_trav)/100) into ct1 from dual;   --floor((sp1*v_taux_trav)/100);
         select SIG.arrondi_bqcentral ((sp2*v_taux_trav)/100)into ct2 from dual; ---floor((sp2*v_taux_trav)/100);
         select SIG.arrondi_bqcentral ((sp3*v_taux_trav)/100) into ct3 from dual; --floor((sp3*v_taux_trav)/100); 

         v_total_sal_trav:=v_total_sal_trav+ ct1+ct2+ct3;
    end if;

     ------cotisation employeur

          if v_occ = 'O' then 
              ce1:=0; 
         ce2:=0; 
         ce3:=0;
                v_total_sal:=v_total_sal+sp1+sp2+sp3; 
          else

         select SIG.arrondi_bqcentral ((sp1*v_taux_empl)/100) into ce1 from dual;   --floor((sp1*v_taux_trav)/100);
         select SIG.arrondi_bqcentral ((sp2*v_taux_empl)/100)into ce2 from dual; ---floor((sp2*v_taux_trav)/100);
         select SIG.arrondi_bqcentral ((sp3*v_taux_empl)/100) into ce3 from dual;
             v_total_sal_empl:=v_total_sal_empl+ce1+ce2+ce3;
             v_total_sal:=v_total_sal+sp1+sp2+sp3;  
     end if;    

       insert into SIG.IMP_COTISATION910(EMPLOYEUR_MATRICULE   , 
DN_RC                  ,
PERIODE                ,
TRAVAILLEUR_MATRICULE,
SALAIRE_M1           ,  
SP1                   , 
CT1                    ,
CE1                    ,
SALAIRE_M2             ,
SP2                    ,
CT2                    ,
CE2                    ,
SALAIRE_M3             ,
SP3                    ,
CT3                    ,
CE3  ,
flag_occ  ,tp1,tp2,tp3  ,v_regime,
v_taux,
v_taux_trav,
v_taux_empl,
v_sal_plaf             ) values 
   (valEmpl           ,
val_dnrc                         ,
valperiode                   ,   
v_TRAV,          
SALAIRE_M1                     ,
SP1                            ,
CT1                            ,
CE1                            ,
SALAIRE_M2                     ,
SP2                            ,
CT2                            ,
CE2                            ,
SALAIRE_M3                     ,
SP3                            ,
CT3                            ,
CE3     ,
v_occ , vtp1,vtp2,vtp3 ,v_regime,
v_taux,
v_taux_trav,
v_taux_empl,
v_sal_plaf                     
   );
 commit;


  end loop;
  close salaire; 


--------------------------------------------------  
end if;



END;

/

