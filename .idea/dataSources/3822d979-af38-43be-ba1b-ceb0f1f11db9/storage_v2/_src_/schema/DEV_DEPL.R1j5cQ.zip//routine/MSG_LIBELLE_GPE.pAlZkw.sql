create FUNCTION          MSG_LIBELLE_GPE(id_gpee varchar2,usermatref varchar2) RETURN varchar2 IS
    retour varchar2(250);
    nomm varchar2(100);
    prenomss varchar2(100);
    surn varchar2(150);
    matr varchar2(6);
    countpart number;
    BEGIN
        BEGIN
            select NOM_GROUPE into retour  from DEV_DEPL.MSG_GPE_DISCUSSION where id = id_gpee;
            exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        IF retour IS NULL THEN
            BEGIN
                select count(*) into countpart  from DEV_DEPL.MSG_GPE_PARTICIPANT_V where id_gpe = id_gpee and matricule_ag != usermatref;
                exception WHEN no_data_found THEN null;
                WHEN TOO_MANY_ROWS THEN null;
            END;
            BEGIN
                IF countpart =  0 THEN
                    BEGIN
                        select nom,prenoms,matricule_ag,surname into nomm,prenomss,matr,surn from (select a.*,rownum rnum from (select * from DEV_DEPL.MSG_GPE_PARTICIPANT_V 
                        where id_gpe = id_gpee and matricule_ag = usermatref order by date_create asc ) a) where rnum = 1;
                        exception WHEN no_data_found THEN null;
                        WHEN TOO_MANY_ROWS THEN null;
                    END;
                ELSE
                    BEGIN
                        select nom,prenoms,matricule_ag,surname into nomm,prenomss,matr,surn from (select a.*,rownum rnum from (select * from DEV_DEPL.MSG_GPE_PARTICIPANT_V 
                        where id_gpe = id_gpee and matricule_ag != usermatref order by date_create asc ) a) where rnum = 1;
                        exception WHEN no_data_found THEN null;
                        WHEN TOO_MANY_ROWS THEN null;
                    END;
                END IF;
                IF nomm IS NOT NULL THEN
                    retour:=nomm;
                END IF;
                IF prenomss IS NOT NULL THEN 
                    retour:=retour||' '||prenomss;
                END IF;
                IF nomm IS NULL AND prenomss IS NULL THEN
                    retour:=matr;
                END IF;
                IF matr = 'SYSTEM' THEN
                    retour:='LUCY No-Reply';
                END IF;
                IF countpart>1 THEN
                    retour:=retour || ' et '||countpart||' Autre(s).';
                ELSE
                    IF surn IS NOT NULL THEN
                        retour:=retour || ' ('||surn||')';
                    END IF;
                END IF;
            END;
        END IF;
        RETURN(retour);
    END;


/

