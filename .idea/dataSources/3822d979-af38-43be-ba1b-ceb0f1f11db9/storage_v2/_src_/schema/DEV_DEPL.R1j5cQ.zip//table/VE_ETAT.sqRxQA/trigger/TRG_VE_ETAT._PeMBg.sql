create trigger TRG_VE_ETAT
    before insert
    on VE_ETAT
    for each row
BEGIN
  :NEW.id_etat := seq_etat.NEXTVAL;
END;
/

