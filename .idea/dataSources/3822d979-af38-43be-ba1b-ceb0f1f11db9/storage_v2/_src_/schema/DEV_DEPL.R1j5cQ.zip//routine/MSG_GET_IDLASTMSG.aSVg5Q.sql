create FUNCTION          MSG_GET_IDLASTMSG(id_gpee varchar2) RETURN varchar2 IS
    retour varchar2(150);
    BEGIN
        BEGIN
            select id into retour from (select a.*, ROWNUM rnum from (select * from DEV_DEPL.MSG_GPE_MESSAGE
            where  id_gpe = id_gpee and etat = 1 order by date_insert desc) a) where rnum = 1;
            exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        RETURN(retour);
    END;

/

