create trigger TRG_CC_CONTACT
    before insert
    on CC_CONTACT
    for each row
BEGIN
    :NEW.id_contact := seq_cc_contact.NEXTVAL;
END;
/

