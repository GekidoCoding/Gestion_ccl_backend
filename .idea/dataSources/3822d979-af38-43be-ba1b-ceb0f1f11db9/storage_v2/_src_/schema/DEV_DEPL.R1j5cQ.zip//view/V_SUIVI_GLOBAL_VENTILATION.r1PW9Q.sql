create view V_SUIVI_GLOBAL_VENTILATION as
SELECT 
    id_demande,
    SUM(montant_total) AS TOTAL_DU,
    SUM(MONTANT_PAYE_CUMULE) AS TOTAL_PAYE,
    CASE 
        WHEN SUM(montant_total) = 0 THEN 0
        ELSE ROUND(SUM(MONTANT_PAYE_CUMULE) / SUM(montant_total) * 100, 2)
    END AS POURCENTAGE_PAYE
FROM VE_VENTILATION
GROUP BY id_demande
/

