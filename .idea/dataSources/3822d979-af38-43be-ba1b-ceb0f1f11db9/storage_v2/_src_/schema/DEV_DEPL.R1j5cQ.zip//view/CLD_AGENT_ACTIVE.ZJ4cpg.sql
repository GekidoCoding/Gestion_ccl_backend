create view CLD_AGENT_ACTIVE as
select act."MATRICULE",act."NOM_AGENT",act."CODE_DIRECTION",act."LIBELLE_DIRECTION",act."CODE_SERVICE",act."LIB_SERVICE",act."CODE_FONCTION",act."LIBELLE_FONCTION",act."DRH_CODE_DR",
CASE WHEN ann.type_fonction IS NULL THEN ' ' ElSE ann.type_fonction END type_fonction,
ann.code_dr,
ann.libelle_dr,
ann.porte,
ann.mail,
ann.interphone,
ann.cellulaire_flotte,
ann.tel_gsm,
ann.sexe,
ann.init
from drh.agent_active_dr act
join INTRANET.view_annuaire_electronique ann on act.matricule=ann.matricule

/

