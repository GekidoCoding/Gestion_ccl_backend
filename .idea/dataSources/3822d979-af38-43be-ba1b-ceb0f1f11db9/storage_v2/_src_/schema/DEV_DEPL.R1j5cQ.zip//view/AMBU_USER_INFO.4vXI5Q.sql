create view AMBU_USER_INFO as
select a.user_matricule,a.username user_oracle,a.code_dr,a.user_init,b.nom,b.prenoms from treso.cnaps_user a join drh.drh_renseignement_agent b on a.user_matricule=b.agent_matricule

/

