create trigger INFRA_PATRIMOINE_TRIGGER
    after insert or update
    on INFRA_PATRIMOINE
    for each row
DECLARE
    action_type VARCHAR2(15); 
BEGIN
	IF INSERTING THEN
        action_type := 'CREATE';

    ELSIF UPDATING THEN
        IF :OLD.deleted != :NEW.deleted THEN
            RETURN;
        ELSE
            action_type := 'UPDATE';
        END IF;
    END IF;
    INSERT INTO Infra_Historique (entite, id, nom, action, matricule, timestamp)
    VALUES (
        'PATRIMOINE',
        :NEW.id_patrimoine,
        :NEW.nom_patrimoine,
        action_type,
        :NEW.matricule,
        CURRENT_TIMESTAMP
    );
END;
/

