create view INV_INVENTAIRES_DETAILS as
select inv."ID"
    ,inv."IMMO_CODE"
    ,inv."DESIGNATION"
    ,inv."USER_INSERT"
    ,inv."CLASSE_CODE"
    ,inv."NATURE_CODE"
    ,inv."SPECIF_CODE"
    ,inv."DATE_INSERT"
    ,inv."AGENT_DETENTEUR"
    ,inv."REFERENCE"
    ,inv."ETAT_IMMO"
    ,inv."CODE_SERVICE"
    ,inv."ETAT"
    ,inv.IMPUTATION
    ,inv.NUM_TEF
    ,inv.VALEUR
    ,inv."AUTRE_USER_INSERT"
    ,inv."LOCALISATION"
    ,ag.nom_agent nom_agent_detenteur
    ,s.libelle_service 
      ,CASE WHEN e.designation is null THEN
            CASE WHEN LOWER(TRIM(INV.ETAT_IMMO)) LIKE '%hors%' THEN 'HORS D''USAGE'
            WHEN LOWER(TRIM(INV.ETAT_IMMO)) LIKE '%neuf%' THEN 'NEUF'
            WHEN LOWER(TRIM(INV.ETAT_IMMO)) LIKE '%bon%' THEN 'BON'
            WHEN LOWER(TRIM(INV.ETAT_IMMO)) LIKE '%panne%' THEN 'PANNE'
            WHEN LOWER(TRIM(INV.ETAT_IMMO)) LIKE '%mauvais%' THEN 'MAUVAIS'
            ELSE 'INCONNU' END
        ELSE e.designation END
      ETAT_LIBELLE
      ,EXTRACT( MONTH FROM inv.DATE_INSERT) mois
      ,EXTRACT( YEAR FROM inv.DATE_INSERT) annee
      from inv_inventaires inv
left join DRH.agent_active_dr ag on inv.agent_detenteur=ag.matricule
LEFT JOIN DRH.DRH_SERVICE S ON S.CODE_SERVICE = inv.CODE_SERVICE
LEFT JOIN INV_ETATS_TEMP E ON  E.ID = TRIM(INV.ETAT_IMMO)

/

