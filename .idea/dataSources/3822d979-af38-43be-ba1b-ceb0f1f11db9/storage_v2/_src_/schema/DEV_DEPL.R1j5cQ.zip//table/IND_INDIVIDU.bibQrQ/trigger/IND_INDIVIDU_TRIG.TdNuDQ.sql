create trigger IND_INDIVIDU_TRIG
    before insert
    on IND_INDIVIDU
    for each row
BEGIN
  SELECT 'I' || TO_CHAR(DEV_DEPL.IND_INDIVIDU_SEQ.NEXTVAL, 'fm000000000')
  INTO   :new.id_individu
  FROM   dual;
END;
/

