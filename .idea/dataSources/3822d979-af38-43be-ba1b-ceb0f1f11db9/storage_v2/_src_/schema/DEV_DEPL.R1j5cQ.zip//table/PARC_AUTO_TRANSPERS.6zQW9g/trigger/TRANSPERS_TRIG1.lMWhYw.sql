create trigger TRANSPERS_TRIG1
    before insert
    on PARC_AUTO_TRANSPERS
    for each row
BEGIN
  SELECT TO_CHAR( :new.DATE_HEURE_DEPART, 'DDMMYYHH24MI' ) || TO_CHAR(:new.N_IMMATRICULATION)
  INTO   :new.REF_TRANSPERS
  FROM   dual;
END;
/

