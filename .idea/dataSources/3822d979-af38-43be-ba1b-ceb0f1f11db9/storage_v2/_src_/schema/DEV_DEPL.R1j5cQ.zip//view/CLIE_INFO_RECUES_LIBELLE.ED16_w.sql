create view CLIE_INFO_RECUES_LIBELLE as
select rc.dossier_numero,rc.abrev,rc.valeur,rc.user_insert,rc.date_insert,rq.titre,rq.prestation_code,
rq.sous_prestation_code,rq.c_format
from SIG.sig_dossiers_info_recues rc 
join sig.sig_dossiers_info_requises rq on rc.abrev=rq.abrev

/

