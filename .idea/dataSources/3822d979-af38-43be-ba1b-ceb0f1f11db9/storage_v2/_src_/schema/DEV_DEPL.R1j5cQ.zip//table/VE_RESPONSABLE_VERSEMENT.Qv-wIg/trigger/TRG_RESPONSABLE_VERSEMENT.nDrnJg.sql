create trigger TRG_RESPONSABLE_VERSEMENT
    before insert
    on VE_RESPONSABLE_VERSEMENT
    for each row
BEGIN
  :NEW.id_responsable := seq_responsable_versement.NEXTVAL;
END;
/

