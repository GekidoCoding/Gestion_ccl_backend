create FUNCTION          MSG_GET_PARTICIPANT(id_gpee varchar2,rnumber number) RETURN varchar2 IS
    retour varchar2(10);
    BEGIN
        BEGIN
            select matricule_ag into retour from (select matricule_ag, ROWNUM rnum, id_gpe from DEV_DEPL.MSG_GPE_PARTICIPANT where id_gpe = id_gpee) where rnum = rnumber;
            exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        RETURN(retour);
    END;


/

