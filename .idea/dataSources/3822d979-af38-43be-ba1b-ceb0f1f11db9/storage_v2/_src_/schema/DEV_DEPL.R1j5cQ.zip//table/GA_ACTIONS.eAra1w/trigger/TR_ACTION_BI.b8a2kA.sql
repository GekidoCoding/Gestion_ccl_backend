create trigger TR_ACTION_BI
    before insert
    on GA_ACTIONS
    for each row
    when (NEW.ACTIONID IS NULL)
BEGIN
    SELECT SEQ_ACTION.NEXTVAL INTO :NEW.ACTIONID FROM DUAL;
END;
/

