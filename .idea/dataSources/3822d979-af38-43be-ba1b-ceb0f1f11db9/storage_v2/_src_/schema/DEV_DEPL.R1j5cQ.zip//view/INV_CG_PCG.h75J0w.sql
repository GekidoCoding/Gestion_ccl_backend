create view INV_CG_PCG as
SELECT 
    "P_LIBC"
    ,"P_FIMP"
    ,"P_XANA"
    ,"P_DCRE"
    ,"P_USER"
    ,"P_CPTG"
    ,"CAT_NUM"
    ,"PCG_ANC"
    ,"NUM_COMPTE"
    ,"D_VIE"
FROM compta.CG_PCG where p_cptg like '218%'

/

