create trigger TRG_CC_ADRESSE
    before insert
    on CC_ADRESSES
    for each row
BEGIN
    :NEW.id_adresse := seq_cc_adresse.NEXTVAL;
END;
/

