create view PRJ_PARTICIPANTS_V as
select p."ID_PART",p."ID_PRJ",p."AGENT_MATRICULE",p."ETAT_PART",p."COMMENTS",p."OBSERVATION",p."TYPE_PART",p."RESPONSABLE",p."USER_INSERT",p."DATE_INSERT",p."USER_MAJ",p."DATE_MAJ", typ.libelle as libelle_type, typ.type_part as type_client, ag.nom, ag.prenoms, ag.libelle_service, ag.mail, ag.cellulaire_flotte
    from dev_depl.prj_participants p join dev_depl.prj_type_participant typ on p.type_part = typ.code_part 
    left join intranet.view_annuaire_electronique ag on p.agent_matricule = ag.matricule
/

