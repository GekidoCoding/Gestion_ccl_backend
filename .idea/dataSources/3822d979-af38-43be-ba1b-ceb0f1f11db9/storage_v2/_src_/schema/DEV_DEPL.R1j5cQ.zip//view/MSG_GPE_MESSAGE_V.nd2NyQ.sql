create view MSG_GPE_MESSAGE_V as
SELECT m."ID",m."ID_PART",m."ID_GPE",m."CONTENU",m."PATH_FILENAME",m."NAME_FILE",m."ETAT",m."USER_INSERT",m."USER_MAJ",m."DATE_INSERT",m."DATE_MAJ",m."COMMENTS",m."TYPE_MSG",m."TYPE_FILE",
p.matricule_ag, p.surname, r.nom, r.prenoms 
from DEV_DEPL.MSG_GPE_MESSAGE m JOIN DEV_DEPL.MSG_GPE_PARTICIPANT p on m.id_part = p.id
LEFT JOIN INTRANET.VIEW_ANNUAIRE_ELECTRONIQUE r ON p.matricule_ag = r.matricule

/

