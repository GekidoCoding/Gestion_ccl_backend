create TYPE          score_gp_rec AS OBJECT (
  taux_total            NUMBER,
  taux_pondere_total    NUMBER,
  kpi                   NUMBER
);
/

