create view TDE_DETAILS as
SELECT t.annee_tde,
          t.code_service,
          t.code_direction,
          dp.DESCRI_DIPLOME AS LIBELLE_DIPLOME,
          td."ID_TDE",
          td."ID_TDE_DTL",
          td."CODE_FONCTION",
          td."EFFECTIFS_DEMANDES",
          td."NIVEAU_ETUDES",
          td."MOTIFS_DEMANDE",
          td."COMMENTAIRES",
          td."USER_INSERT",
          td."DATE_INSERT",
          td."AVIS_DIR",
          td."EFFECTIFS_DIR",
          td."USER_DIR",
          td."DATE_DIR",
          td."COMMENT_DIR",
          td."EFFECTIFS_CMRT",
          td."TYPE_AFFECTATION",
          td."USER_CMRT",
          td."DATE_CMRT",
          td."LOCALITE",
          td."EFFECTIF_AGENTS",
          dr.libelle_direction,
          serv.libelle_service,
          NVL (serv.CODE_zone,serv.CODE_DIRECTION) CODE_zones,
          DRH.libelle_service (
             NVL (serv.CODE_zone,serv.CODE_DIRECTION))
             LIBELLE_zone,
          fc.libelle_fonction
     FROM drh.drh_tde t
          JOIN drh.drh_tde_detail td
             ON t.ID_TDE = td.ID_TDE
          JOIN drh.drh_direction dr
             ON t.CODE_DIRECTION = dr.code_direction
          JOIN drh.drh_service serv
             ON t.code_service = serv.code_service
          LEFT JOIN drh.drh_fonction_1 fc
             ON td.code_fonction = fc.code_fonction
          JOIN dempr_diplome dp
             ON dp.id_diplome = td.niveau_etudes

/

