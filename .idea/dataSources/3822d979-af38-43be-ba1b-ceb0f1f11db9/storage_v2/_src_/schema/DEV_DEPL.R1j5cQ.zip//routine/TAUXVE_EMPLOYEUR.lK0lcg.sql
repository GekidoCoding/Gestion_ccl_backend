create FUNCTION     tauxve_employeur(empl char,per number) RETURN char IS  
    v_per number;

Begin 

begin
SELECT max(TAUX_ENCAISSEMENT) into v_per
FROM TRESO.vve_empl
Where  EMPLOYEUR_MATRICULE=empl and PERIODE_DEBUT <=per and 
   PERIODE_FIN >=per;
exception when no_data_found then v_per:=0;
end;

  if v_per >=50 then
 		return('N');
  else
  	return('O');  	
  End if;	
End;

/

