create view CC_V_APPELS_PAR_HEURE as
SELECT 
        TRUNC(date_heure_appel) AS date_appel,
        EXTRACT(HOUR FROM date_heure_appel) AS heure,
        COUNT(*) AS nb_appels
    FROM cc_v_details_appels
    GROUP BY 
        TRUNC(date_heure_appel), 
        EXTRACT(HOUR FROM date_heure_appel)
/

