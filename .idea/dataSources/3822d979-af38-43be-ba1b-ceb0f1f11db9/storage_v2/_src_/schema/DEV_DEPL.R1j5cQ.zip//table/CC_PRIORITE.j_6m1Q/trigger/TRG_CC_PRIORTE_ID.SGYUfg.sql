create trigger TRG_CC_PRIORTE_ID
    before insert
    on CC_PRIORITE
    for each row
BEGIN
    :NEW.id_priorite := seq_cc_priorite.NEXTVAL;
END;
/

