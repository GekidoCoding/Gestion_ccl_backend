create view CC_V_DETAILS_APPELS as
SELECT 
    appel.id_appel, 
    appel.agent_matricule,
    appel.client_matricule,
    appel.id_type_entrant,
    cte.TYPE_ENTRANT_LIBELLE,
    appel.nom_client,
    appel.prenom_client,
    appel.telephone_client,
    appel.id_statut_appel,
    sa.STATUT_LIBELLE,
    appel.id_sous_prestation,
    sp.SOUS_PRESTATION,
    appel.transfer,
    appel.id_service,
    cs.SERVICE_LIBELLE,
    appel.id_priorite,
    cp.PRIORITE_LIBELLE,
    ca.id_categorie_appel,
    ca.categorie_libelle,
    cta.id_cat_type_appel,
    cta.cat_type_libelle,
    appel.date_heure_appel,
    appel.date_heure_fin_appel,
    TO_CHAR(appel.date_heure_fin_appel - appel.date_heure_appel) AS duree_appel,
    appel.telephone1,
    appel.telephone2,
    appel.motif
FROM cc_appel appel 
JOIN cc_type_entrant cte
    ON appel.id_type_entrant = cte.id_type_entrant
JOIN cc_statut_appel sa 
    ON appel.id_statut_appel = sa.id_statut_appel
JOIN cc_sous_prestation sp
    ON appel.id_sous_prestation = sp.id_sous_prestation
JOIN cc_service cs
    ON appel.id_service = cs.id_service
JOIN cc_priorite cp 
    ON appel.id_priorite = cp.id_priorite
JOIN cc_categorie_appel ca
    ON appel.id_categorie_appel = ca.id_categorie_appel
JOIN cc_categorie_type_appel cta
    ON appel.id_cat_type_appel = cta.id_cat_type_appel
/

