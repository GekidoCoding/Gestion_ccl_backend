create view CLD_DETAILS_CALENDRIER as
select cl."ID",cl."DATE_INSERT",cl."ANNEE",cl."ID_PRESTATION",cl."USER_INSERT",pre.libelle libelle_prestation
,etp.id id_etape,etp.etat etat_etape,etp.date_insert date_insert_etape,etp.libelle libelle_etape,etp.ordre ordre_etape,etp.user_insert user_insert_etape
,setp.id id_sous_etape,setp.date_insert date_insert_sous_etape,setp.etat etat_sous_etape,setp.libelle libelle_sous_etape,setp.ordre ordre_sous_etape,setp.user_insert unser_insert_sous_etape
,setp_per.id_periodes,setp_per.DATE_PREVU,setp_per.DATE_EFFECTIF,setp_per.USER_INSERT user_insert_sous_etape_periode,setp_per.DATE_INSERT date_insert_sous_etape_periode,setp_per.OBSERVATION,setp_per.ETAT_FIN,setp_per.LIBELLE_PERIODE,setp_per.NUMERO_PERIODE
from  cld_calendrier cl 
join  cld_prestations pre on cl.id_prestation=pre.id 
join  cld_etapes etp on cl.id=etp.id_calendrier
join  cld_sous_etapes setp on etp.id=setp.id_etapes
join (SELECT SE.*,PER.LIBELLE LIBELLE_PERIODE,PER.NUMERO NUMERO_PERIODE FROM  CLD_SOUS_ETAPES_PERIODES SE JOIN  CLD_PERIODES PER ON SE.ID_PERIODES=PER.ID) setp_per on setp.id=setp_per.id_sous_etapes

/

