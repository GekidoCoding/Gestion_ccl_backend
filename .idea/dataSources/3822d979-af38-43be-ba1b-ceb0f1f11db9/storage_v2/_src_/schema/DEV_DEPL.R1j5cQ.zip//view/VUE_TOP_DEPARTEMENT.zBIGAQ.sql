create view VUE_TOP_DEPARTEMENT as
SELECT
    d.iddepartement,
    d.libelledepartement,
    COUNT(a.idactivite) AS nb_taches
FROM ga_activites a
JOIN ga_agents ag ON a.idagent = ag.idagent
JOIN ga_services s ON ag.idservice = s.idservice
JOIN ga_departements d ON s.iddepartement = d.iddepartement
GROUP BY d.iddepartement, d.libelledepartement
/

