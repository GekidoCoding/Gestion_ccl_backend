create FUNCTION getListBenefConcat(num_ticket VARCHAR2) RETURN VARCHAR2 AS
        result_string VARCHAR2(4000);
        BEGIN
            SELECT LISTAGG(nom_prenoms, ', ') WITHIN GROUP (ORDER BY nom_prenoms) INTO result_string
            FROM (
                SELECT DISTINCT nom_prenoms
                FROM SIG.MAINT_DEMANDE_MAT_DET_V
                WHERE id_dmd = num_ticket AND nom_prenoms IS NOT NULL
                GROUP BY nom_prenoms
            );

            RETURN result_string;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                RETURN '-'; 
        END;

/

