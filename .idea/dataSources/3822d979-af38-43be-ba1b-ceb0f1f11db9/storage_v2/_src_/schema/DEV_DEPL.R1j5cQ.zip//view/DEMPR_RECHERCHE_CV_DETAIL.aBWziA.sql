create view DEMPR_RECHERCHE_CV_DETAIL as
select a."DESCRI_OBSERVATION",a."NUMERO_DOSSIER",a."DATE_RECEPTION",a."ETAT",a."OBSERVATION",a."CODE_CV",a."NOM",a."PRENOM",a."DATE_NAISSANCE",a."LIEU_NAISSANCE",a."SEXE",a."ADRESSE",a."TELEPHONE",a."EMAIL",a."POSTE_DEMANDEE",a."TYPE_DEMANDE",a."PROVENANCE",a."DESCRI_TYPE_DEMANDE",a."DESCRI_DEMANDE",a."AGE",a."SITUATION_FAMILIALE",a."TOTAL_MOIS_XP",a."TOTAL_MOIS_XP_LIBELLE",a."RECHERCHE",
b.id_experience,b.poste,b.domaine,b.societe,b.mois_xp,b.mois_xp_libelle,b.date_debut,b.date_fin,b.descri_poste,b.descri_domaine,b.descri_societe,
c.id_formation,c.diplome,c.filiere,c.ecole,c.annee_obtention,c.descri_diplome,c.descri_filiere,c.descri_ecole
from dempr_recherche_cv  a left join dempr_experience_pro_detail b on a.code_cv=b.code_cv left join dempr_formation_detail c on a.code_cv=c.code_cv

/

