create view V_VE_RESPONSABLE_VERSEMENT as
SELECT
    r.id_responsable,
    r.nom,
    r.prenom,
    r.contact,
    f.id_fonction_responsable as id_fonction,
    f.libelle as fonction,
    r.piece_identifiant,
    r.nom_prenom_mere,
    r.matricule_employeur,
    e.raison_sociale ,
    e.mail,
    e.adresse
FROM
    ve_responsable_versement r
JOIN 
    ve_fonction_responsable f
ON 
    f.id_fonction_responsable = r.id_fonction_responsable
JOIN
    sig.SIG_EMPLOYEUR_INFO e
ON
    r.matricule_employeur = e.matricule
/

