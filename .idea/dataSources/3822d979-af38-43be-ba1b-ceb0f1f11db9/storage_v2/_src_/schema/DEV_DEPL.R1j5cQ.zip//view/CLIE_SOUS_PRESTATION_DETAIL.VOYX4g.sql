create view CLIE_SOUS_PRESTATION_DETAIL as
select sp.sous_prestation_code,sp.sous_prestation_libelle,sp.sous_prestation_abreviation,p.prestation_code,p.prestation_libelle,p.prestation_abreviation
from sig.sig_sous_prestations sp join sig.sig_prestations p on sp.prestation_code=p.prestation_code

/

