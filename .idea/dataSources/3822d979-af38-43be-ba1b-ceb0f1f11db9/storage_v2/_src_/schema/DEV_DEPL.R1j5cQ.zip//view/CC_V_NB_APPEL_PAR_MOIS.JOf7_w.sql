create view CC_V_NB_APPEL_PAR_MOIS as
WITH mois AS (
        SELECT LEVEL AS mois_num, 
            TO_CHAR(TO_DATE(LEVEL, 'MM'), 'Month') AS mois
        FROM dual
        CONNECT BY LEVEL <= 12
    ),
    annees AS (
        SELECT DISTINCT EXTRACT(YEAR FROM date_heure_appel) AS annee
        FROM cc_v_details_appels
    )
    SELECT 
        a.annee,
        m.mois_num,
        m.mois,
        COALESCE(COUNT(c.id_appel), 0) AS nb_appel
    FROM mois m
    CROSS JOIN annees a
    LEFT JOIN cc_v_details_appels c 
        ON EXTRACT(MONTH FROM c.date_heure_appel) = m.mois_num
        AND EXTRACT(YEAR FROM c.date_heure_appel) = a.annee
    GROUP BY 
        a.annee,
        m.mois_num,
        m.mois
    ORDER BY 
        a.annee, 
        m.mois_num
/

