create view VW_DELAI_PAIEMENT as
SELECT
    d.matricule_employeur,
    vd.id_detail,
    vd.date_echeance,
    p.date_paiement,
    (p.date_paiement - vd.date_echeance) AS delai_jours,
    CASE
        WHEN p.date_paiement IS NULL THEN 
            CASE 
                WHEN SYSDATE > vd.date_echeance THEN 'Non payé - en retard'
                ELSE 'Non payé - pas encore échu'
            END
        WHEN (p.date_paiement - vd.date_echeance) = 0 THEN 'À temps'
        WHEN (p.date_paiement - vd.date_echeance) > 0 THEN 'En retard'
        ELSE 'À temps (anticipé)'
    END AS statut_paiement
FROM VE_VENTILATION_DETAIL vd
LEFT JOIN VE_PAIEMENT p 
    ON p.id_ventilation_detail = vd.id_detail
JOIN VE_VENTILATION v 
    ON vd.id_ventilation = v.id_ventilation
JOIN VE_DEMANDE_VE d 
    ON v.id_demande = d.id_demande_ve
/

