create view VW_RETARD_PONDERE as
SELECT
    TRUNC(p.date_paiement, 'MM') AS mois,
    SUM(CASE WHEN p.date_paiement > d.date_echeance THEN p.montant_du ELSE 0 END) / 
    SUM(p.montant_du) * 100 AS pct_retard_pondere
FROM VE_PAIEMENT p
JOIN VE_VENTILATION_DETAIL d ON p.ID_VENTILATION_detail = d.ID_DETAIL
WHERE d.date_echeance <= TRUNC(SYSDATE)
GROUP BY TRUNC(p.date_paiement, 'MM')
ORDER BY TRUNC(p.date_paiement, 'MM')
/

