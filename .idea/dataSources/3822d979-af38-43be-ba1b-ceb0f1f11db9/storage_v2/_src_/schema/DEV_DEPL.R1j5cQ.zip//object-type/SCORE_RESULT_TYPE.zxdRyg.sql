create TYPE          score_result_type AS OBJECT (
    score_realisation     NUMBER,
    realisation_ponderee  NUMBER,
    kpi                   NUMBER
);
/

