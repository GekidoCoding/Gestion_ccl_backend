create trigger TRG_DEMANDE_VE_DETAIL
    before insert
    on DEMANDE_VE_DETAIL
    for each row
BEGIN
  :NEW.id_demande_ve_detail := seq_demande_ve_detail.NEXTVAL;
END;
/

