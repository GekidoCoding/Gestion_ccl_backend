create view INV_IMMO_SPECIFICITES as
SELECT "CLE_SPE"
        ,"SPECIF_SPE"
        ,"NATURE_SPE"
        ,"CLASSE_SPE"
        ,"LIBELLE_SPE"
FROM immo.immo_specificites spec where spec.specif_spe is not null
and spec.nature_spe is not null and spec.classe_spe is not null and
spec.libelle_spe is not null

/

