create view DEMPR_DOMAINE_STATS as
select b."DESCRI_OBSERVATION",b."NUMERO_DOSSIER",b."DATE_RECEPTION",b."ETAT",b."OBSERVATION",b."CODE_CV",b."NOM",b."PRENOM",b."DATE_NAISSANCE",b."LIEU_NAISSANCE",b."SEXE",b."ADRESSE",b."TELEPHONE",b."EMAIL",b."POSTE_DEMANDEE",b."TYPE_DEMANDE",b."PROVENANCE",b."DESCRI_TYPE_DEMANDE",b."DESCRI_DEMANDE",b."AGE",b."SITUATION_FAMILIALE",b."TOTAL_MOIS_XP",b."TOTAL_MOIS_XP_LIBELLE",b."MOIS",b."ANNEE",a.domaine from 
(select * from (select a.code_cv,b.domaine from dempr_cv_detail a join dempr_experience_pro b on a.code_cv=b.code_cv)tab group by tab.code_cv,tab.domaine)a
join dempr_cv_detail_stats b on a.code_cv=b.code_cv

/

