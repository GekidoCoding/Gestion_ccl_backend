create view MOAPP_COMPTE_EMPL as
SELECT MATRICULE,
             PERIODE,
             tarification_obligatoire,
             tarification_complementaire,
             majoration_retard,
             debit,
             CREDIT,
             solde,
             TAUX_IMPAYE,
             taux_crg,
             CASE
                 WHEN debit = 0 AND CREDIT > 0
                 THEN
                     'Sans Tarification'
                 ELSE
                     CASE
                         WHEN debit = 0 AND CREDIT = 0
                         THEN
                             treso.obs_sit_cpt (MATRICULE, PERIODE)
                         ELSE
                             CASE WHEN taux_crg IS NOT NULL THEN 'CRG' END
                     END
             END
                 observation
        FROM (SELECT MATRICULE,
                     PERIODE,
                     TARIF_910
                         tarification_obligatoire,
                     TARIF_900
                         tarification_complementaire,
                     MR_DU
                         majoration_retard,
                     NVL (TARIF_910, 0) + NVL (TARIF_900, 0) + NVL (MR_DU, 0)
                         debit,
                     CREDIT,
                     SOLDE_REEL
                         solde,
                     TAUX_IMPAYE,
                     treso.crg_empl_taux (MATRICULE, PERIODE)
                         taux_crg
                FROM BAL_AGEE.BA_EMPL_PER)
    ORDER BY PERIODE DESC

/

