create FUNCTION          MSG_IMAGE_GPE(id_gpee varchar2,usermatref varchar2) RETURN varchar2 IS
    retour varchar2(6);
    countpart number;
    BEGIN
        BEGIN
            select count(*) into countpart  from DEV_DEPL.MSG_GPE_PARTICIPANT_V where id_gpe = id_gpee and matricule_ag != usermatref;
            exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        BEGIN
            IF countpart =  0 THEN
                retour:=usermatref;
            ELSE
                BEGIN
                    select matricule_ag into retour from (select a.*,rownum rnum from (select * from DEV_DEPL.MSG_GPE_PARTICIPANT_V 
                    where id_gpe = id_gpee and matricule_ag != usermatref order by date_create asc ) a) where rnum = 1;
                        exception WHEN no_data_found THEN null;
                        WHEN TOO_MANY_ROWS THEN null;
                    END;
                END IF;
                IF countpart>1 THEN
                    retour:='GROUPE';
                END IF;
            END;
        RETURN(retour);
    END;


/

