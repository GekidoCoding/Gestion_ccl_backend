create trigger TRG_ACTIVITE
    before insert
    on KPI_ACTIVITE
    for each row
BEGIN 
    SELECT 'ACT'||LPAD(dev_depl.kpi_seq_activite.NEXTVAL, 10, '0') INTO :NEW.id_activite FROM DUAL;
END;
/

