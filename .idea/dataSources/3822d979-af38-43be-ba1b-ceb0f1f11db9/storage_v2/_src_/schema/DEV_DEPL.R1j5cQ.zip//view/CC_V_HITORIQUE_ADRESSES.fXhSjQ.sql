create view CC_V_HITORIQUE_ADRESSES as
SELECT
        cch.id_historique,
        cch.client_matricule,
        cch.agent_matricule,
        cch.id_code_ad,
        ccca.code_libelle,
        cch.oldValue,
        cch.newValue,
        cch.date_update
    FROM CC_HISTORIQUE_ADRESSES cch
    JOIN CC_CODE_ADRESSES ccca
        ON cch.ID_CODE_AD = ccca.ID_CODE_AD
    ORDER BY date_update DESC
/

