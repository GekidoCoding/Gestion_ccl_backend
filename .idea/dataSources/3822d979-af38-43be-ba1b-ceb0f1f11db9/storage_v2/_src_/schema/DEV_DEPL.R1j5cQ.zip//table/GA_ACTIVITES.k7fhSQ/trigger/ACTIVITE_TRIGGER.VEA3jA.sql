create trigger ACTIVITE_TRIGGER
    before insert
    on GA_ACTIVITES
    for each row
BEGIN
    SELECT activite_seq.NEXTVAL INTO :NEW.idActivite FROM DUAL;
END;
/

