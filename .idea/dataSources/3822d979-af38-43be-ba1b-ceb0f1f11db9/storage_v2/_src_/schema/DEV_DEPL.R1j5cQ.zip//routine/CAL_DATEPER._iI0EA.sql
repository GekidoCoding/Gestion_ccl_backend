create FUNCTION     cal_dateper( pdate date )
RETURN char IS
vv_mois char(2);
vv_annee char(4);
BEGIN
if pdate is not null then
 vv_mois:=to_char(pdate,'MM');
 vv_annee:=to_char(pdate,'YYYY');
if vv_mois in ('01','02','03')  then
 return(vv_annee||'01');
elsif vv_mois in ('04','05','06')  then
 return(vv_annee||'02');
elsif vv_mois in ('07','08','09')  then
 return(vv_annee||'03');
elsif vv_mois in ('10','11','12')  then
 return(vv_annee||'04');
end if;
else
return('201801');
end if;
END;
/

