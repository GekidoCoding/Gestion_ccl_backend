create view CC_V_NB_APPEL_ENTRANT_SORTANT as
select
        id_categorie_appel,
        categorie_libelle,
        COUNT(id_categorie_appel) as nb_appel
    from cc_v_details_appels c
        group by
            id_categorie_appel,
            categorie_libelle
/

