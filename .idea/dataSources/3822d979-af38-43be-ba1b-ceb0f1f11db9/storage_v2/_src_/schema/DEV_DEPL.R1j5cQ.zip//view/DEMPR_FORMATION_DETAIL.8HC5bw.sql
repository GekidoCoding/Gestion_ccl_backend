create view DEMPR_FORMATION_DETAIL as
select a."ID_FORMATION",a."CODE_CV",a."DIPLOME",a."FILIERE",a."ECOLE",a."ANNEE_OBTENTION",b.descri_diplome,c.descri_filiere,d.descri_ecole
from dempr_formation_diplome a join dempr_diplome b on a.diplome=b.id_diplome join dempr_filiere c on a.filiere=c.id_filiere join dempr_ecole d on a.ecole=d.id_ecole

/

