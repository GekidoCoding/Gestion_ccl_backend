create view CLIE_DOSSIERS_DETAILS as
SELECT d.DOSSIER_NUMERO,
          d.PRESTATION_CODE,
          d.TRAVAILLEUR_MATRICULE,
          d.SOUS_PRESTATION_CODE,
          d.NUM_TEL,
          d.USER_VALIDE_N2,
          d.DATE_VALIDE_N2,
          d.DOSSIER_DATE_RECEPTION,
          d.DATE_RECEP_DR,
          d.FLAG_VALIDE_N2,
          p.prestation_libelle,
          sp.sous_prestation_libelle,
          trav.travailleur_nom,
          trav.travailleur_prenom
     FROM sig.sig_dossiers d
          JOIN sig.sig_prestations p
             ON d.prestation_code = p.prestation_code
          JOIN sig.sig_sous_prestations sp
             ON d.sous_prestation_code = sp.sous_prestation_code
          JOIN sig.sig_travailleurs trav
             ON d.travailleur_matricule = trav.travailleur_matricule
/

