create trigger TRG_CC_HITORIQUE_ADRESSE
    before insert
    on CC_HISTORIQUE_ADRESSES
    for each row
BEGIN
    :NEW.id_historique := seq_cc_historique_adresse.NEXTVAL;
END;
/

