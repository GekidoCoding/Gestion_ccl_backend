create trigger TRG_CC_SOUS_PRESTATION_ID
    before insert
    on CC_SOUS_PRESTATION
    for each row
BEGIN
    :NEW.id_sous_prestation := seq_cc_sous_prestation.NEXTVAL;
END;
/

