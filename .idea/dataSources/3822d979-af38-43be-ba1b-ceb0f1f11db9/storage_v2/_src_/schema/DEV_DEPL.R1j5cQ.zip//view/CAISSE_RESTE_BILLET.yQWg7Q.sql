create view CAISSE_RESTE_BILLET as
select  caisse,VALEUR_BILLET, SUM(
       CASE
            WHEN TYPE = 'ENTRE' THEN QUANTITE
           ELSE -QUANTITE
        END) RESTE
      from
(SELECT CASE
            WHEN appro.caisse is null THEN op.caisse
            ELSE appro.caisse
        END CAISSE,VALEUR_BILLET,QUANTITE,type
        FROM CAISSE_BILLET_MOUVEMENT MVT
        left JOIN CAISSE_OPERATIONS OP ON OP.ID_OPERATION = MVT.REFERENCE_ORIGINE
        left join caisse_approvisionnements appro on appro.id_approvisionnement=mvt.reference_origine)
        WHERE VALEUR_BILLET>=50
        GROUP BY VALEUR_BILLET,caisse order by VALEUR_BILLET desc

/

