create trigger TRG_CC_CATEGORIE_APPEL
    before insert
    on CC_CATEGORIE_APPEL
    for each row
BEGIN
    :NEW.id_categorie_appel := seq_cc_categorie_appel.NEXTVAL;
END;
/

