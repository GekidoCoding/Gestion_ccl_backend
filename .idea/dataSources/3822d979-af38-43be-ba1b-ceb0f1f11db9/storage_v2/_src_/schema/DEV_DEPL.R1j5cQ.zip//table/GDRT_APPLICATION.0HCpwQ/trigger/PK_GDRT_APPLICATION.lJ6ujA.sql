create trigger PK_GDRT_APPLICATION
    before insert
    on GDRT_APPLICATION
    for each row
begin  
   if inserting then 
      if :NEW."ID" is null then 
         select SEQ_APPLICATION.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
end;

/

