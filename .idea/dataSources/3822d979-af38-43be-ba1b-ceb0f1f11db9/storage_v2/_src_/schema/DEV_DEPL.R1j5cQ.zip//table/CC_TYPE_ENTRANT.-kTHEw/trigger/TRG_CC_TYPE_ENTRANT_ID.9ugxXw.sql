create trigger TRG_CC_TYPE_ENTRANT_ID
    before insert
    on CC_TYPE_ENTRANT
    for each row
BEGIN
    :NEW.id_type_entrant := seq_cc_type_entrant.NEXTVAL;
END;
/

