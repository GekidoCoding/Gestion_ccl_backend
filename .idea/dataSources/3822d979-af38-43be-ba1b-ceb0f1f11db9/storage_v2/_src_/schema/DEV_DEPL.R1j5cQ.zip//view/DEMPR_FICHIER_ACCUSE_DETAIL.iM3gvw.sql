create view DEMPR_FICHIER_ACCUSE_DETAIL as
select a."ID_FICHIER_ACCUSE",a."TYPE_FICHIER_ACCUSE",a."NUMERO_ACCUSE",b.descri_type_fichier from dempr_fichier_accuse_reception a join dempr_type_fichier b on a.type_fichier_accuse=b.id_type_fichier

/

