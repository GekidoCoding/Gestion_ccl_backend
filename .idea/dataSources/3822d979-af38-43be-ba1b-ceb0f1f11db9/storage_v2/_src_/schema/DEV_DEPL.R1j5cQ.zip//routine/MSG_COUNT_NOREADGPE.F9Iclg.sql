create FUNCTION          MSG_COUNT_NOREADGPE(id_gpee varchar2,userm varchar2) RETURN number IS
    retour number;
    lastread varchar2(150);
    dat timestamp;
    BEGIN
        BEGIN
            select last_msg_read into lastread from DEV_DEPL.MSG_GPE_PARTICIPANT where matricule_ag = userm and id_gpe = id_gpee;
            exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        BEGIN
            IF lastread IS NULL THEN
                BEGIN
                    select count (*) into retour from DEV_DEPL.MSG_GPE_MESSAGE where id_gpe = id_gpee and etat = 1;
                    exception WHEN no_data_found THEN null;
                    WHEN TOO_MANY_ROWS THEN null;
                END;
            ELSE
                BEGIN
                    -- select date_insert into dat from DEV_DEPL.MSG_GPE_MESSAGE where id_gpe = id_gpee and etat = 1 AND id = lastread;
                    select date_insert into dat from DEV_DEPL.MSG_GPE_MESSAGE where id = lastread;
                    exception WHEN no_data_found THEN null;
                    WHEN TOO_MANY_ROWS THEN null;
                END;
                IF dat IS NULL THEN
                    retour:=1;
                ELSE 
                    BEGIN
                        -- select count (*) into retour from DEV_DEPL.MSG_GPE_MESSAGE where id_gpe = id_gpee and etat = 1 AND id > lastread AND date_insert > dat;
                        select count (*) into retour from DEV_DEPL.MSG_GPE_MESSAGE where id_gpe = id_gpee and etat = 1 AND date_insert > dat;
                        exception WHEN no_data_found THEN null;
                        WHEN TOO_MANY_ROWS THEN null;
                    END;
                END IF;
            END IF;
        END;
        IF retour IS NULL THEN
            retour:=0;
        END IF;
        RETURN(retour);
    END;

/

