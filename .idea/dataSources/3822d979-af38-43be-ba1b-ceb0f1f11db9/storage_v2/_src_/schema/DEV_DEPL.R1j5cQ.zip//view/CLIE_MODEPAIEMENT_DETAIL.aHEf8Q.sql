create view CLIE_MODEPAIEMENT_DETAIL as
select mpb.mode_code,mpb.banque_code,bq.banque_libelle,md.mode_libelle
from dev_depl.clie_modepaiements_banques mpb 
join treso.trs_banques bq on mpb.banque_code=bq.banque_code
join treso.trs_modepaiements md on md.mode_code=mpb.mode_code

/

