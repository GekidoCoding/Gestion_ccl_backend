create view PRJ_HISTO_ETAT_V as
SELECT h."ID_HE",h."USER_HE",h."DATE_HE",h."OBSERVATION",h."COMMENTS",h."ID_PRJ",h."ID_PHASE",h."ETAT_PRJ", p.libelle as libelle_phase from DEV_DEPL.PRJ_HISTO_ETAT h JOIN DEV_DEPL.PRJ_PHASE_PROJET p ON h.id_phase = p.id_phase
/

