create FUNCTION          PRJ_GET_PART_PROJET(id_projet VARCHAR2,type_partic VARCHAR2, resp VARCHAR2) RETURN VARCHAR2 AS
    result_string VARCHAR2(4000);
    BEGIN
        -- SELECT LISTAGG(nom || ' ' || prenoms || ' (' || agent_matricule || ')', ', ') WITHIN GROUP (ORDER BY date_insert) INTO result_string
        SELECT LISTAGG( nvl(prenoms,nom) || ' (' || agent_matricule || ')', ', ') WITHIN GROUP (ORDER BY date_insert) INTO result_string
        FROM (
            select p.id_part, p.id_prj, p.agent_matricule, p.etat_part, t.code_part, p.responsable, p.date_insert, t.libelle as libelle_type, t.type_part,
            ag.nom, ag.prenoms from DEV_DEPL.PRJ_PARTICIPANTS p LEFT JOIN DEV_DEPL.PRJ_TYPE_PARTICIPANT t on p.type_part = t.code_part
            left join drh.drh_renseignement_agent ag on p.agent_matricule = ag.agent_matricule
            WHERE p.id_prj=id_projet AND p.etat_part = 1 and p.responsable = resp and t.type_part = type_partic
        );
        IF result_string IS NULL THEN
            result_string:='-';
        END IF;
        RETURN result_string;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN '-'; 
    END;
/

