create view CSOM_DETAIL_CO_LIBELLE_COULEUR as
SELECT
    d.id,
    d.commande,
    d.produit,
    d.quantite,
    d.couleur COULEURID,
    C.DESIGNATION COULEUR
    
FROM CSOM_DETAIL_COMMANDE D
LEFT JOIN CSOM_COULEUR C ON C.ID = D.COULEUR

/

