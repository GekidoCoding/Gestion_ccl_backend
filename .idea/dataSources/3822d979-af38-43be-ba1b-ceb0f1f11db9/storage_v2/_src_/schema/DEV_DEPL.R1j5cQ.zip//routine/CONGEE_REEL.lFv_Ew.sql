create FUNCTION CONGEE_REEL(matricule char) RETURN varchar2 IS
    retour varchar2(100);
    reliquat_last number; --min
    annee_reliquat_last number; --année
    current_year number;
    current_month_of_year number;
    nb_annee_diff number;
    droit_jour_par_mois number:=2.5;--jour
    min_jour number:=450;--nombre de minute par jour
    droit_annee_diff number;
    droit_annee_en_cours number;
    reliqmin_reel number;
    BEGIN
        BEGIN
SELECT reliqmin,annee INTO reliquat_last,annee_reliquat_last
            FROM drh.drh_reliquat
            WHERE agent_matricule=matricule 
AND annee=(SELECT max(annee) FROM drh.drh_reliquat
            WHERE agent_matricule=matricule);
            exception WHEN no_data_found THEN null;
            WHEN TOO_MANY_ROWS THEN null;
        END;
        BEGIN
            SELECT EXTRACT(year FROM sysdate),EXTRACT(month FROM sysdate) INTO
                current_year, current_month_of_year FROM DUAL;
        END;
        IF annee_reliquat_last = current_year THEN
            IF reliquat_last < 0 THEN
                reliquat_last:=0;
            END IF;
            retour:=DRH.DUREEJ(reliquat_last);
        END IF; 
        IF annee_reliquat_last < current_year THEN
            nb_annee_diff:= current_year - annee_reliquat_last - 1;
            droit_annee_diff:= nb_annee_diff * 12 * droit_jour_par_mois * min_jour;
            droit_annee_en_cours:= current_month_of_year * droit_jour_par_mois * min_jour;
            reliqmin_reel:= droit_annee_en_cours + droit_annee_diff + reliquat_last;
            retour:=DRH.DUREEJ(reliqmin_reel);
        END IF;
        RETURN(retour);
    END;


/

