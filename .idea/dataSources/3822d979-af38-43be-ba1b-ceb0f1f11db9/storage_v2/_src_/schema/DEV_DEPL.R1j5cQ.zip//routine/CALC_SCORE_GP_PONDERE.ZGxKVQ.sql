create FUNCTION          calc_score_GP_pondere ( INDICATEUR_TYPE varchar2,  CONSIDERATION number,  PONDERATION number, OBJECTIF number,  REALISATION number)
RETURN number
IS
    v_taux_total           NUMBER := 0;
    v_taux_pondere_total   NUMBER := 0;
    v_ponderation_total    NUMBER := 0;
    v_kpi                  NUMBER := 0;
BEGIN
  if CONSIDERATION=0 then
    RETURN  ROUND(0);
else
        DECLARE
            v_taux       NUMBER := 0;
            v_pondere    NUMBER := 0;
        BEGIN
            IF OBJECTIF = 0 THEN
                null;
            END IF;

            -- Taux de réalisation
            v_taux := CASE 
                        WHEN INDICATEUR_TYPE = 'OUI/NON' THEN
                            CASE WHEN REALISATION = OBJECTIF THEN 1 ELSE 0 END
                        ELSE
                            REALISATION / OBJECTIF
                      END;

            -- Pondéré
            v_pondere := v_taux * PONDERATION;

            -- Accumulation
            v_taux_total := v_taux_total + v_taux;
            v_taux_pondere_total := v_taux_pondere_total + v_pondere;
            v_ponderation_total := v_ponderation_total + PONDERATION;
        END;
   

    IF v_ponderation_total = 0 THEN
        RETURN 0;
    END IF;

    v_kpi := v_taux_pondere_total / v_ponderation_total;

    RETURN  ROUND(v_taux_pondere_total, 2);
    end if;
END;
/

