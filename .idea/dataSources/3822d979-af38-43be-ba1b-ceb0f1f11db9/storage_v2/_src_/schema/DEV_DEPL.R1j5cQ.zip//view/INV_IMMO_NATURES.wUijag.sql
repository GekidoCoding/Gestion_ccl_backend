create view INV_IMMO_NATURES as
SELECT 
    "CLE_NAT"
    ,"NATURE_NAT"
    ,"CLASSE_NAT"
    ,"LIBELLE_NAT"
FROM IMMO.IMMO_NATURES nat where nat.nature_nat is not null
and nat.classe_nat is not null and nat.libelle_nat is not null

/

