create trigger TRG_CC_CODE_ADRESSE
    before insert
    on CC_CODE_ADRESSES
    for each row
BEGIN
    :NEW.id_code_ad := seq_cc_code_adresse.NEXTVAL;
END;
/

